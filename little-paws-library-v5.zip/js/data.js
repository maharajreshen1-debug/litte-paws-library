/* ===== Little Paws Library - Data ===== */
/* Structure is designed so new books can be added easily later */

const BOOKS = [
  {
    id: 1,
    title: "The Adventures of Papi",
    shortTitle: "The Lost Bone",
    emoji: "🦴",
    description: "Papi loses his favourite bone and embarks on a journey of friendship, kindness and courage.",
    chapters: [
      {
        title: "A Missing Bone",
        text: "Papi loves playing in his garden. One day his special bone goes missing! With a worried heart he sets off to find it, meeting new friends along the way.",
        unlocks: ["papi", "bella"]
      },
      {
        title: "New Friends Appear",
        text: "Papi meets Bella the rabbit and other kind animals who offer help. Together they face challenges and learn that working as a team makes everything possible.",
        unlocks: ["ollie", "felix"]
      },
      {
        title: "The Mountain & The Lesson",
        text: "After climbing high and never giving up, Papi finds his bone. More importantly, he discovers the true treasure is the friends he made and the kindness they shared.",
        unlocks: ["toby"]
      }
    ],
    moral: "Friendship and kindness are the greatest treasures of all."
  },
  {
    id: 2,
    title: "The Missing Treasure of Puppy Island",
    shortTitle: "Puppy Island",
    emoji: "🏝️",
    description: "A mysterious map leads Papi and friends to Puppy Island in search of a lost treasure.",
    chapters: [
      {
        title: "The Mysterious Package",
        text: "Papi receives a strange package containing a map and a note from someone called T.J. An adventure to Puppy Island begins!",
        unlocks: ["oliver", "sammy"]
      },
      {
        title: "Friends & Foes",
        text: "On the island the group meets helpful animals and faces a pirate parrot who steals the map. Teamwork helps them recover it.",
        unlocks: ["bruno", "manny"]
      },
      {
        title: "The Real Treasure",
        text: "In the end the greatest treasure is not gold, but the friendship and courage the group showed together.",
        unlocks: ["tyson"]
      }
    ],
    moral: "True treasure is found in friendship and working together."
  },
  {
    id: 3,
    title: "The Ghost of Hound Manor",
    shortTitle: "Hound Manor",
    emoji: "👻",
    description: "A spooky mystery at Hound Manor leads Papi and friends to discover the truth behind the 'ghost'.",
    chapters: [
      {
        title: "Strange Happenings",
        text: "Missing posters and odd events in Moonlight Village send Papi, Rosie and Oliver on a new investigation.",
        unlocks: ["rosie", "jackie"]
      },
      {
        title: "Into the Manor",
        text: "The friends bravely enter Hound Manor and meet new helpers along the way, including a bear and a mouse.",
        unlocks: ["billy", "willy", "sandy"]
      },
      {
        title: "The Truth Revealed",
        text: "The 'ghost' turns out to be something unexpected. Courage and honesty bring the mystery to a happy end.",
        unlocks: ["mike"]
      }
    ],
    moral: "Courage and truth can solve even the scariest mysteries."
  },
  {
    id: 4,
    title: "The Tomb of the Pharaoh",
    shortTitle: "Pharaoh's Tomb",
    emoji: "🏺",
    description: "An ancient map sends Papi to Egypt where riddles, a Sphinx and a lost tomb await.",
    chapters: [
      {
        title: "Journey to Egypt",
        text: "Oliver delivers an ancient map. Papi and friends travel by hot-air balloon to the land of pyramids and pharaohs.",
        unlocks: ["cammy"]
      },
      {
        title: "Riddles & Guardians",
        text: "They face a cobra, a crocodile guardian and the great Sphinx. Only friendship and clever thinking open the way.",
        unlocks: ["croco"]
      },
      {
        title: "The Real Treasure",
        text: "Inside the tomb they learn that the greatest treasure was never gold — it was family, friendship and staying true.",
        unlocks: ["brutus"]
      }
    ],
    moral: "True treasure isn't gold — it is the love of family and friends."
  },
  {
    id: 5,
    title: "Mystery in the Australian Outback",
    shortTitle: "Australian Outback",
    emoji: "💎",
    description: "When a famous diamond goes missing, Papi and friends must clear Sammy's name and catch the real thieves.",
    chapters: [
      {
        title: "Sammy in Trouble",
        text: "Sammy is accused of stealing a precious diamond. Papi and Rosie fly to Australia to help their friend.",
        unlocks: ["cooper", "kim"]
      },
      {
        title: "Clues in the Outback",
        text: "Detective Peter the Platypus joins the case. The group follows tracks through markets, caves and hidden mines.",
        unlocks: ["peter", "brian"]
      },
      {
        title: "Truth Comes Out",
        text: "Greed and lies are exposed. Honesty and teamwork free Sammy and bring the real culprits to justice.",
        unlocks: ["dan", "andy"]
      }
    ],
    moral: "Honesty is always the best choice. Teamwork can solve any mystery."
  },
  {
    id: 6,
    title: "The Magic of the Arctic",
    shortTitle: "Arctic Magic",
    emoji: "❄️",
    description: "A mysterious blue light freezes the Arctic. Papi and Oliver must help restore warmth and understanding.",
    chapters: [
      {
        title: "A Frozen Land",
        text: "Oliver receives a worried note from his cousin Owen. Papi and Oliver fly to the Arctic and find everything covered in ice.",
        unlocks: ["owen", "benny"]
      },
      {
        title: "New Arctic Friends",
        text: "They meet Fred the Arctic Fox, Peggy the Polar Bear and wise Winston the Walrus. Together they cross frozen lakes and face blizzards.",
        unlocks: ["fred", "peggy", "winston", "harry"]
      },
      {
        title: "Understanding & Warmth",
        text: "The friends discover the truth about Wendy and the stolen staff. Kindness and understanding melt the ice and bring the village back to life.",
        unlocks: ["wendy", "poppy"]
      }
    ],
    moral: "Don't judge others before knowing them. Kindness and understanding can warm even the coldest places."
  }
];


const CHARACTERS = [
  { id: "papi", name: "Papi", traits: ["Brave", "Kind", "Loyal"], emoji: "🐶", role: "The Hero", book: 1, cost: 0, isVillain: false, card: "images/characters/cards/papi.jpg", description: "Brave, kind and full of heart. Papi loves adventure, his friends and most of all… his home. Special Gift: Courage and a loyal heart." },
  { id: "rosie", name: "Rosie", traits: ["Caring", "Kind"], emoji: "🐰", role: "The Rabbit", book: 1, cost: 80, isVillain: false, card: "images/characters/cards/rosie.jpg", description: "Sweet, caring and always ready to help. Rosie brings kindness and warmth to every adventure. Special Gift: Kindness and a helping hand." },
  { id: "oliver", name: "Oliver", traits: ["Wise", "Thoughtful"], emoji: "🦉", role: "The Owl", book: 2, cost: 80, isVillain: false, card: "images/characters/cards/oliver.jpg", description: "Wise and thoughtful. Oliver sees the big picture and helps friends make the right choices. Special Gift: Wisdom and clear thinking." },
  { id: "sammy", name: "Sammy", traits: ["Energetic", "Cheerful"], emoji: "🐿️", role: "The Squirrel", book: 2, cost: 80, isVillain: false, card: "images/characters/cards/sammy.jpg", description: "Energetic, playful and always excited to help. Sammy's enthusiasm keeps everyone going! Special Gift: Energy and positive spirit." },
  { id: "toby", name: "Toby", traits: ["Patient", "Steady"], emoji: "🐢", role: "The Turtle", book: 1, cost: 80, isVillain: false, card: "images/characters/cards/toby.jpg", description: "Slow and steady with a big determined heart. Toby teaches everyone that perseverance wins. Special Gift: Perseverance and patience." },
  { id: "felix", name: "Felix", traits: ["Clever", "Mischievous"], emoji: "🦊", role: "The Fox", book: 1, cost: 30, isVillain: false, card: "images/characters/cards/felix.jpg", description: "Clever and mischievous. Felix loves tricks and testing Papi and his friends… but learns important lessons too! Special Gift: Cleverness and quick thinking." },
  { id: "cora", name: "Cora", traits: ["Curious", "Smart"], emoji: "🐦‍⬛", role: "The Crow", book: 2, cost: 30, isVillain: false, card: "images/characters/cards/cora.jpg", description: "Smart, sassy and curious. Cora loves solving puzzles and always has a new challenge for the team. Special Gift: Curiosity and problem solving." },
  { id: "benny", name: "Benny", traits: ["Loyal", "Cheerful"], emoji: "🦭", role: "The Seal", book: 6, cost: 30, isVillain: false, card: "images/characters/cards/benny.jpg", description: "Cheerful and loyal. Benny is always ready with a smile and a helping flipper! Special Gift: Loyalty and cheerfulness." },
  { id: "bruno", name: "Bruno", traits: ["Wise", "Patient"], emoji: "🐕", role: "The Wise Old Dog", book: 2, cost: 30, isVillain: false, card: "images/characters/cards/bruno.jpg", description: "Kind, patient and wise. Bruno teaches Papi the most important lesson of all about courage, friendship and home. Special Gift: Wisdom and understanding." },
  { id: "delilah", name: "Delilah", traits: ["Graceful", "Brave"], emoji: "🐬", role: "The Dolphin", book: 2, cost: 30, isVillain: false, card: "images/characters/cards/delilah.jpg", description: "A kind and graceful dolphin who loves adventure and helping her friends. Kind heart, brave & smart, loves the ocean." },
  { id: "jackie", name: "Jackie", traits: ["Sneaky", "Tricky"], emoji: "🐺", role: "The Jackal", book: 3, cost: 150, isVillain: true, card: "images/characters/cards/jackie.jpg", description: "Jackie is mean, sneaky and tricky. He loves causing trouble and sending others the wrong way. He only cares about himself and getting what he wants." },
  { id: "timmy", name: "Timmy", traits: ["Funny", "Cheerful"], emoji: "🐸", role: "The Frog", book: 3, cost: 30, isVillain: false, card: "images/characters/cards/timmy.jpg", description: "Timmy is cheerful, funny and full of surprises! He loves to make his friends laugh and brighten any gloomy day." },
  { id: "billy", name: "Billy", traits: ["Gentle", "Helpful"], emoji: "🐻", role: "The Friendly Bear", book: 3, cost: 30, isVillain: false, card: "images/characters/cards/billy.jpg", description: "Billy is kind, caring and always ready to help. He loves the forest and knows all the best places to find food, build shelters and stay safe. Billy's gentle heart and big hugs make everyone feel better, even on the toughest days!" },
  { id: "willy", name: "Willy", traits: ["Brave", "Clever"], emoji: "🐭", role: "The Little Mouse", book: 3, cost: 30, isVillain: false, card: "images/characters/cards/willy.jpg", description: "Willy is small but very brave and clever. He may be tiny, but his heart is big. Willy uses his quick thinking and sharp eyes to help his friends solve problems. He believes that everyone, no matter how small, can make a BIG difference!" },
  { id: "sandy", name: "Sandy", traits: ["Gentle", "Wise"], emoji: "🐍", role: "The Snake", book: 4, cost: 30, isVillain: false, card: "images/characters/cards/sandy.jpg", description: "Sandy is gentle and wise. She may be small, but she has a brave heart and is always there for her friends." },
  { id: "mike", name: "Mike", traits: ["Loyal", "Courageous"], emoji: "🦮", role: "The Golden Retriever", book: 3, cost: 30, isVillain: false, card: "images/characters/cards/mike.jpg", description: "Mike is wise, kind and loyal. He loves helping his friends and protecting those he cares about. Mike believes that courage, kindness and loyalty can light the way through any challenge." },
  { id: "gregory", name: "Gregory", traits: ["Wise", "Thoughtful"], emoji: "🐐", role: "The Goat", book: 3, cost: 30, isVillain: false, card: "images/characters/cards/gregory.jpg", description: "Gregory is wise, thoughtful and full of wonderful stories. He has traveled many places and loves to help his friends with advice and guidance. Gregory believes that knowledge, patience and kindness can solve any problem." },
  { id: "cooper", name: "Cooper", traits: ["Kind", "Clever"], emoji: "🐨", role: "The Koala", book: 5, cost: 30, isVillain: false, card: "images/characters/cards/cooper.jpg", description: "Cooper is kind, clever and always looks out for his friends. He knows the Outback well and is never afraid to help." },
  { id: "kim", name: "Kim", traits: ["Strong", "Energetic"], emoji: "🦘", role: "The Kangaroo", book: 5, cost: 30, isVillain: false, card: "images/characters/cards/kim.jpg", description: "Kim is strong, energetic and a great jumper! She keeps everyone moving forward and never gives up." },
  { id: "peter", name: "Detective Peter", traits: ["Curious", "Sharp"], emoji: "🦆", role: "The Platypus", book: 5, cost: 30, isVillain: false, card: "images/characters/cards/peter.jpg", description: "Detective Peter is sharp, curious and always solves the case! He notices every detail no one else sees." },
  { id: "andy", name: "Andy", traits: ["Greedy", "Mean"], emoji: "🐊", role: "The Alligator", book: 5, cost: 150, isVillain: true, card: "images/characters/cards/andy.jpg", description: "Andy is greedy, mean and loves to cause trouble. He thinks he's the boss and wants everything for himself!" },
  { id: "brian", name: "Brian", traits: ["Sneaky", "Spy"], emoji: "🦇", role: "The Bat", book: 5, cost: 150, isVillain: true, card: "images/characters/cards/brian.jpg", description: "Brian is sneaky and loves to spy on others. He is always hatching a plan to trick his friends." },
  { id: "timothy", name: "Timothy", traits: ["Wild", "Impulsive"], emoji: "😈", role: "The Tasmanian Devil", book: 5, cost: 150, isVillain: true, card: "images/characters/cards/timothy.jpg", description: "Timothy is wild, impulsive and loves causing chaos. He never thinks before he acts!" },
  { id: "dan", name: "Dan", traits: ["Cunning", "Unfair"], emoji: "🐺", role: "The Dingo", book: 5, cost: 150, isVillain: true, card: "images/characters/cards/dan.jpg", description: "Dan is cunning and doesn't play fair. He follows Andy and helps him cause trouble in the Outback." },
  { id: "peggy", name: "Peggy", traits: ["Strong", "Caring"], emoji: "🐻‍❄️", role: "The Polar Bear", book: 6, cost: 30, isVillain: false, card: "images/characters/cards/peggy.jpg", description: "Peggy is kind and strong. She cares for her friends and always helps those in need in the Arctic." },
  { id: "fred", name: "Fred", traits: ["Clever", "Quick"], emoji: "🦊", role: "The Cunning Arctic Fox", book: 6, cost: 30, isVillain: false, card: "images/characters/cards/fred.jpg", description: "Fred is clever and quick. He loves adventures and uses his smarts to help his friends solve problems." },
  { id: "poppy", name: "Poppy", traits: ["Cheerful", "Playful"], emoji: "🐧", role: "The Penguin", book: 6, cost: 30, isVillain: false, card: "images/characters/cards/poppy.jpg", description: "Poppy is cheerful and playful. She brings joy to everyone and always has a positive attitude." },
  { id: "winston", name: "Winston", traits: ["Wise", "Magical"], emoji: "🦭", role: "The Magical Walrus", book: 6, cost: 30, isVillain: false, card: "images/characters/cards/winston.jpg", description: "Winston is wise and magical. He knows ancient spells that protect the Arctic and its animals." },
  { id: "harry", name: "Harry", traits: ["Energetic", "Brave"], emoji: "🐰", role: "The Arctic Hare", book: 6, cost: 30, isVillain: false, card: "images/characters/cards/harry.jpg", description: "Harry is energetic and brave. He can leap across snowy hills and is always ready to lend a hand." },
  { id: "owen", name: "Owen", traits: ["Intelligent", "Observant"], emoji: "🦉", role: "Oliver's Cousin – The Arctic Owl", book: 6, cost: 30, isVillain: false, card: "images/characters/cards/owen.jpg", description: "Owen is intelligent and observant. He sees everything from above and guides his friends with his wisdom." },
  { id: "wendy", name: "Wendy", traits: ["Powerful", "Misunderstood"], emoji: "🐺", role: "The Sorceress Wolf", book: 6, cost: 150, isVillain: true, card: "images/characters/cards/wendy.jpg", description: "Wendy is powerful and wants the magic of the Arctic for herself. She will stop at nothing to get what she wants." },
  { id: "ismael", name: "King Ismael", traits: ["Noble", "Protective"], emoji: "🐕", role: "The Pharaoh", book: 4, cost: 80, isVillain: false, card: "images/characters/cards/ismael.jpg", description: "King Ismael is the wise and noble ruler of Egypt. He is powerful, kind and always protects his kingdom and his people." },
  { id: "mystic", name: "Mystic", traits: ["Brave", "Loyal"], emoji: "🐈", role: "The Pharaoh's Trusted Warrior", book: 4, cost: 30, isVillain: false, card: "images/characters/cards/mystic.jpg", description: "Mystic is brave, clever and loyal. She guards the Pharaoh with her sharp mind and her fighting skills. She is always ready for any danger." },
  { id: "ralph", name: "Ralph", traits: ["Strong", "Disciplined"], emoji: "🐕", role: "The Pharaoh's Trusted Warrior", book: 4, cost: 30, isVillain: false, card: "images/characters/cards/ralph.jpg", description: "Ralph is strong, disciplined and fearless. He stands beside Mystic and will do whatever it takes to keep Egypt safe." },
  { id: "brutus", name: "Brutus", traits: ["Greedy", "Power-hungry"], emoji: "🐶", role: "The Greedy Villain", book: 4, cost: 150, isVillain: true, card: "images/characters/cards/brutus.jpg", description: "Brutus is greedy and power-hungry. He wants the Pharaoh's treasures for himself and will stop at nothing to rule Egypt with darkness and fear." },
  { id: "cammy", name: "Cammy", traits: ["Helpful", "Kind"], emoji: "🐪", role: "The Camel", book: 4, cost: 30, isVillain: false, card: "images/characters/cards/cammy.jpg", description: "Cammy is a kind and helpful camel. She travels across the desert with her friends and always knows the way when they need help." },
  { id: "baabi", name: "Baabi", traits: ["Funny", "Clever"], emoji: "🐵", role: "The Baboon", book: 4, cost: 30, isVillain: false, card: "images/characters/cards/baabi.jpg", description: "Baabi is a clever and funny baboon. He loves to giggle and make jokes, but he has a big heart and always helps his friends." },
  { id: "carl", name: "Carl", traits: ["Calm", "Observant"], emoji: "🐍", role: "The Cobra", book: 4, cost: 30, isVillain: false, card: "images/characters/cards/carl.jpg", description: "Carl is clever, calm and very observant. He notices things that others might miss and uses his wisdom to help his friends in tricky situations. Carl believes that a smart mind and a brave heart can overcome any danger." },
  { id: "croco", name: "Croco", traits: ["Wise", "Powerful"], emoji: "🐊", role: "The Crocodile", book: 4, cost: 30, isVillain: false, card: "images/characters/cards/croco.jpg", description: "Croco the Crocodile is a wise desert-river guardian in Egypt. Thoughtful, powerful, and dressed in royal jewels by the Nile at sunset." },

  // --- Previously missing characters (now fully wired) ---
  { id: "bella", name: "Bella", traits: ["Helpful", "Sweet"], emoji: "🐰", role: "The Bunny", book: 1, cost: 30, isVillain: false, card: "images/characters/cards/bella.jpg", description: "Kind and helpful from the very first adventure. Bella was one of the first friends to offer Papi help when his bone went missing. Special Gift: A warm, helpful heart." },
  { id: "ollie", name: "Ollie", traits: ["Playful", "Brave"], emoji: "🦦", role: "The Otter", book: 1, cost: 30, isVillain: false, card: "images/characters/cards/ollie.jpg", description: "Playful and brave. Ollie gave Papi a ride across the river and loves water adventures. Special Gift: Courage and a playful spirit." },
  { id: "manny", name: "Manny", traits: ["Fun", "Energetic"], emoji: "🐵", role: "The Monkey", book: 2, cost: 30, isVillain: false, card: "images/characters/cards/manny.jpg", description: "Fun-loving and full of energy. Manny swings through the trees of Puppy Island and always has a clever idea. Special Gift: Energy and quick thinking." },
  { id: "tyson", name: "Tyson", traits: ["Strong", "Loyal"], emoji: "🐯", role: "The Tiger", book: 2, cost: 80, isVillain: false, card: "images/characters/cards/tyson.jpg", description: "Strong, loyal and protective. Tyson becomes a true friend on Puppy Island and helps guard the real treasure — friendship. Special Gift: Strength and loyalty." },
  { id: "paulie", name: "Paulie", traits: ["Clever", "Cheeky"], emoji: "🦜", role: "The Pirate Parrot", book: 2, cost: 30, isVillain: false, card: "images/characters/cards/paulie.jpg", description: "A colourful pirate parrot who knows the secrets of Puppy Island. He gives clues (and a little cheeky advice) along the way. Special Gift: Clever tips and pirate flair." },
  { id: "tj", name: "TJ", traits: ["Sneaky", "Greedy"], emoji: "🐺", role: "The Wolf", book: 2, cost: 150, isVillain: true, card: "images/characters/cards/tj.jpg", description: "TJ the Wolf wants the island treasure for himself! He tries to stop Papi and his friends, but teamwork and kindness always win." },

];




// Outfit shop – available after a character is unlocked
const OUTFITS = [
  { id: "hat-red", name: "Red Cap", emoji: "🧢", cost: 40 },
  { id: "hat-party", name: "Party Hat", emoji: "🎉", cost: 50 },
  { id: "scarf-blue", name: "Blue Scarf", emoji: "🧣", cost: 35 },
  { id: "scarf-winter", name: "Winter Scarf", emoji: "❄️", cost: 45 },
  { id: "glasses", name: "Cool Glasses", emoji: "🕶️", cost: 40 },
  { id: "bowtie", name: "Bow Tie", emoji: "🎀", cost: 30 },
  { id: "crown", name: "Golden Crown", emoji: "👑", cost: 80 },
  { id: "backpack", name: "Adventure Pack", emoji: "🎒", cost: 55 },
  { id: "cape", name: "Hero Cape", emoji: "🦸", cost: 70 },
  { id: "flower", name: "Flower Crown", emoji: "🌸", cost: 35 }
];

// World map areas – locked until the matching book is completed
const WORLD_AREAS = [
  { id: 1, name: "Book 1: Garden & Forest", emoji: "🌲", book: 1, theme: "forest", weather: "leaves", lockedDesc: "Finish Book 1 – The Lost Bone" },
  { id: 2, name: "Book 2: Puppy Island", emoji: "🏝️", book: 2, theme: "island", weather: "sun", lockedDesc: "Finish Book 2 – Puppy Island" },
  { id: 3, name: "Book 3: Moonlight Village", emoji: "🌙", book: 3, theme: "night", weather: "fog", lockedDesc: "Finish Book 3 – Hound Manor" },
  { id: 4, name: "Book 4: Egyptian Desert", emoji: "🏜️", book: 4, theme: "desert", weather: "sand", lockedDesc: "Finish Book 4 – Pharaoh Tomb" },
  { id: 5, name: "Book 5: Australian Outback", emoji: "🪨", book: 5, theme: "outback", weather: "heat", lockedDesc: "Finish Book 5 – Australian Outback" },
  { id: 6, name: "Book 6: Arctic Lands", emoji: "❄️", book: 6, theme: "arctic", weather: "snow", lockedDesc: "Finish Book 6 – Arctic Magic" }
];



const COLOURING_PAGES = [
  { id: "cp-papi", title: "Colour Papi", emoji: "🐶", cost: 40, characterId: "papi", image: "images/colouring/pages/papi.jpg" },
  { id: "cp-rosie", title: "Colour Rosie", emoji: "🐰", cost: 35, characterId: "rosie", image: "images/colouring/pages/rosie.jpg" },
  { id: "cp-oliver", title: "Colour Oliver", emoji: "🦉", cost: 35, characterId: "oliver", image: "images/colouring/pages/oliver.jpg" },
  { id: "cp-sammy", title: "Colour Sammy", emoji: "🐿️", cost: 35, characterId: "sammy", image: "images/colouring/pages/sammy.jpg" },
  { id: "cp-toby", title: "Colour Toby", emoji: "🐢", cost: 35, characterId: "toby", image: "images/colouring/pages/toby.jpg" },
  { id: "cp-felix", title: "Colour Felix", emoji: "🦊", cost: 25, characterId: "felix", image: "images/colouring/pages/felix.jpg" },
  { id: "cp-cora", title: "Colour Cora", emoji: "🐦‍⬛", cost: 25, characterId: "cora", image: "images/colouring/pages/cora.jpg" },
  { id: "cp-benny", title: "Colour Benny", emoji: "🦭", cost: 25, characterId: "benny", image: "images/colouring/pages/benny.jpg" },
  { id: "cp-bruno", title: "Colour Bruno", emoji: "🐕", cost: 25, characterId: "bruno", image: "images/colouring/pages/bruno.jpg" },
  { id: "cp-delilah", title: "Colour Delilah", emoji: "🐬", cost: 25, characterId: "delilah", image: "images/colouring/pages/delilah.jpg" },
  { id: "cp-jackie", title: "Colour Jackie", emoji: "🐺", cost: 30, characterId: "jackie", image: "images/colouring/pages/jackie.jpg" },
  { id: "cp-timmy", title: "Colour Timmy", emoji: "🐸", cost: 25, characterId: "timmy", image: "images/colouring/pages/timmy.jpg" },
  { id: "cp-billy", title: "Colour Billy", emoji: "🐻", cost: 25, characterId: "billy", image: "images/colouring/pages/billy.jpg" },
  { id: "cp-willy", title: "Colour Willy", emoji: "🐭", cost: 25, characterId: "willy", image: "images/colouring/pages/willy.jpg" },
  { id: "cp-sandy", title: "Colour Sandy", emoji: "🐍", cost: 25, characterId: "sandy", image: "images/colouring/pages/sandy.jpg" },
  { id: "cp-mike", title: "Colour Mike", emoji: "🦮", cost: 25, characterId: "mike", image: "images/colouring/pages/mike.jpg" },
  { id: "cp-gregory", title: "Colour Gregory", emoji: "🐐", cost: 25, characterId: "gregory", image: "images/colouring/pages/gregory.jpg" },
  { id: "cp-cooper", title: "Colour Cooper", emoji: "🐨", cost: 25, characterId: "cooper", image: "images/colouring/pages/cooper.jpg" },
  { id: "cp-kim", title: "Colour Kim", emoji: "🦘", cost: 25, characterId: "kim", image: "images/colouring/pages/kim.jpg" },
  { id: "cp-peter", title: "Colour Detective Peter", emoji: "🦆", cost: 25, characterId: "peter", image: "images/colouring/pages/peter.jpg" },
  { id: "cp-andy", title: "Colour Andy", emoji: "🐊", cost: 30, characterId: "andy", image: "images/colouring/pages/andy.jpg" },
  { id: "cp-brian", title: "Colour Brian", emoji: "🦇", cost: 30, characterId: "brian", image: "images/colouring/pages/brian.jpg" },
  { id: "cp-timothy", title: "Colour Timothy", emoji: "😈", cost: 30, characterId: "timothy", image: "images/colouring/pages/timothy.jpg" },
  { id: "cp-dan", title: "Colour Dan", emoji: "🐺", cost: 30, characterId: "dan", image: "images/colouring/pages/dan.jpg" },
  { id: "cp-peggy", title: "Colour Peggy", emoji: "🐻‍❄️", cost: 25, characterId: "peggy", image: "images/colouring/pages/peggy.jpg" },
  { id: "cp-fred", title: "Colour Fred", emoji: "🦊", cost: 25, characterId: "fred", image: "images/colouring/pages/fred.jpg" },
  { id: "cp-poppy", title: "Colour Poppy", emoji: "🐧", cost: 25, characterId: "poppy", image: "images/colouring/pages/poppy.jpg" },
  { id: "cp-winston", title: "Colour Winston", emoji: "🦭", cost: 25, characterId: "winston", image: "images/colouring/pages/winston.jpg" },
  { id: "cp-harry", title: "Colour Harry", emoji: "🐰", cost: 25, characterId: "harry", image: "images/colouring/pages/harry.jpg" },
  { id: "cp-owen", title: "Colour Owen", emoji: "🦉", cost: 25, characterId: "owen", image: "images/colouring/pages/owen.jpg" },
  { id: "cp-wendy", title: "Colour Wendy", emoji: "🐺", cost: 30, characterId: "wendy", image: "images/colouring/pages/wendy.jpg" },
  { id: "cp-ismael", title: "Colour King Ismael", emoji: "🐕", cost: 35, characterId: "ismael", image: "images/colouring/pages/ismael.jpg" },
  { id: "cp-mystic", title: "Colour Mystic", emoji: "🐈", cost: 25, characterId: "mystic", image: "images/colouring/pages/mystic.jpg" },
  { id: "cp-ralph", title: "Colour Ralph", emoji: "🐕", cost: 25, characterId: "ralph", image: "images/colouring/pages/ralph.jpg" },
  { id: "cp-brutus", title: "Colour Brutus", emoji: "🐶", cost: 30, characterId: "brutus", image: "images/colouring/pages/brutus.jpg" },
  { id: "cp-cammy", title: "Colour Cammy", emoji: "🐪", cost: 25, characterId: "cammy", image: "images/colouring/pages/cammy.jpg" },
  { id: "cp-baabi", title: "Colour Baabi", emoji: "🐵", cost: 25, characterId: "baabi", image: "images/colouring/pages/baabi.jpg" },
  { id: "cp-carl", title: "Colour Carl", emoji: "🐍", cost: 25, characterId: "carl", image: "images/colouring/pages/carl.jpg" },
  { id: "cp-paulie", title: "Colour Paulie", emoji: "🦜", cost: 25, characterId: "paulie", image: "images/colouring/pages/paulie.jpg" },
  { id: "cp-tj", title: "Colour TJ", emoji: "🐺", cost: 30, characterId: "tj", image: "images/colouring/pages/tj.jpg" },
  { id: "cp-tyson", title: "Colour Tyson", emoji: "🐯", cost: 40, characterId: "tyson", image: "images/colouring/pages/tyson.jpg" },
  { id: "cp-manny", title: "Colour Manny", emoji: "🐵", cost: 25, characterId: "manny", image: "images/colouring/pages/manny.jpg" },
  { id: "cp-ollie", title: "Colour Ollie", emoji: "🦦", cost: 25, characterId: "ollie", image: "images/colouring/pages/ollie.jpg" },
  { id: "cp-bella", title: "Colour Bella", emoji: "🐰", cost: 25, characterId: "bella", image: "images/colouring/pages/bella.jpg" },
  { id: "cp-croco", title: "Colour Croco", emoji: "🐊", cost: 25, characterId: "croco", image: "images/colouring/pages/croco.jpg" },

];



/* Interactive Story Maps – locations for each book adventure */
const STORY_MAPS = {
  1: {
    title: "The Adventures of Papi — Finding Home",
    theme: "forest",
    image: "images/maps/book1-map.jpg",
    locations: [
      { id: "home1", name: "Home Sweet Home", traits: ["Friendly", "Special"], emoji: "🏠", x: 8, y: 22, desc: "This is Papi. He is a happy little Yorkie who loves his bone!" },
      { id: "yard", name: "The Yard", traits: ["Friendly", "Special"], emoji: "🦴", x: 22, y: 20, desc: "Papi loved to play with his bone in the yard every day." },
      { id: "accident", name: "The Accident", traits: ["Friendly", "Special"], emoji: "😮", x: 35, y: 18, desc: "But one day… his bone rolled away!" },
      { id: "search", name: "The Search Begins", traits: ["Friendly", "Special"], emoji: "🔍", x: 48, y: 22, desc: "He looked everywhere, but he couldn't find it. Papi's adventure is about to begin!" },
      { id: "bella", name: "New Friend – Bella", traits: ["Helpful", "Sweet"], emoji: "🐰", x: 68, y: 18, desc: "Papi met Bella the Bunny. “I'll help you look.”" },
      { id: "ollie", name: "New Friend – Ollie", traits: ["Playful", "Brave"], emoji: "🦦", x: 82, y: 28, desc: "Ollie the Otter gave Papi a ride across the river." },
      { id: "sammy-oliver", name: "Sammy & Oliver", traits: ["Friendly", "Special"], emoji: "🐿️", x: 78, y: 42, desc: "Papi met Sammy the Squirrel and Oliver the Owl. “We'll help you too!”" },
      { id: "toby", name: "New Friend – Toby", traits: ["Patient", "Steady"], emoji: "🐢", x: 55, y: 48, desc: "Toby the Turtle promised to help Papi cross the river." },
      { id: "felix", name: "Felix the Fox", traits: ["Clever", "Mischievous"], emoji: "🦊", x: 32, y: 45, desc: "Papi met Felix the Fox. Felix tried to trick him, but Papi stayed clever!" },
      { id: "cora", name: "Cora the Crow", traits: ["Curious", "Smart"], emoji: "🐦‍⬛", x: 12, y: 42, desc: "A grumpy crow named Cora tried to block the path. But Papi didn't give up!" },
      { id: "kindness", name: "Kindness", traits: ["Friendly", "Special"], emoji: "💛", x: 12, y: 58, desc: "Papi stayed calm and kind. Cora let him pass." },
      { id: "keepgoing", name: "Keep Going", traits: ["Friendly", "Special"], emoji: "⛰️", x: 28, y: 65, desc: "Papi climbed tall hills, walked through deep forests, and never gave up." },
      { id: "helping", name: "Helping Together", traits: ["Friendly", "Special"], emoji: "🤝", x: 48, y: 62, desc: "With teamwork and encouragement, everyone helped Papi find his bone!" },
      { id: "found", name: "Found!", traits: ["Friendly", "Special"], emoji: "✨", x: 62, y: 58, desc: "Under a hollow log, Papi found his favourite bone!" },
      { id: "homeagain", name: "Home Again", traits: ["Friendly", "Special"], emoji: "🌅", x: 82, y: 68, desc: "Papi arrived home as the sun began to set. Home never felt so wonderful." },
      { id: "bestfriends", name: "Best Friends", traits: ["Friendly", "Special"], emoji: "💖", x: 42, y: 82, desc: "He found his bone, but more importantly, he found the best friends forever." },
      { id: "homebest", name: "Home Is the Best", traits: ["Friendly", "Special"], emoji: "🏡", x: 58, y: 85, desc: "No matter where you go, home is where love lives." },
      { id: "theend", name: "The End", traits: ["Friendly", "Special"], emoji: "😴", x: 78, y: 88, desc: "And so, Papi drifted off to sleep with a full heart and sweet dreams." }
    ]
  },
  2: {
    title: "Puppy Island — Missing Treasure",
    theme: "island",
    image: "images/maps/book2-map.jpg",
    locations: [
      { id: "papihome", name: "Papi's Home", traits: ["Friendly", "Special"], emoji: "🏠", x: 10, y: 22, desc: "This is Papi. He is a happy little Yorkie who loves adventures!" },
      { id: "map", name: "The Mysterious Map", traits: ["Friendly", "Special"], emoji: "🗺️", x: 28, y: 18, desc: "Papi and his friends find a mysterious map. It leads to a secret treasure on Puppy Island!" },
      { id: "paulie", name: "Paulie the Pirate Parrot", traits: ["Clever", "Cheeky"], emoji: "🦜", x: 72, y: 12, desc: "Paulie gives them clues and tells them about the island. But beware of danger!" },
      { id: "jungle", name: "The Jungle Path", traits: ["Friendly", "Special"], emoji: "🌴", x: 82, y: 32, desc: "The jungle is thick and tricky. The friends must stick together and keep moving forward." },
      { id: "bridge", name: "Suspension Bridge", traits: ["Friendly", "Special"], emoji: "🌉", x: 52, y: 38, desc: "They carefully cross the wobbly bridge. Teamwork helps them get across!" },
      { id: "waterfall", name: "The Waterfall", traits: ["Friendly", "Special"], emoji: "💦", x: 22, y: 48, desc: "They follow the waterfall to find the next clue hidden behind the roaring water!" },
      { id: "tj", name: "TJ the Wolf", traits: ["Sneaky", "Greedy"], emoji: "🐺", x: 12, y: 62, desc: "TJ the Wolf wants the treasure for himself! He tries to stop Papi and his friends." },
      { id: "cave", name: "Cave Path", traits: ["Friendly", "Special"], emoji: "🕳️", x: 28, y: 72, desc: "The path leads near a glowing cave on the island." },
      { id: "treasure", name: "The Treasure Chest", traits: ["Friendly", "Special"], emoji: "💎", x: 48, y: 78, desc: "They find the treasure chest filled with golden bones and shiny treasures!" },
      { id: "caught", name: "TJ Is Caught!", traits: ["Friendly", "Special"], emoji: "🪢", x: 68, y: 72, desc: "Together, the friends outsmart TJ. Kindness and cleverness win the day!" },
      { id: "sailing", name: "Sailing Home", traits: ["Friendly", "Special"], emoji: "⛵", x: 88, y: 58, desc: "With the treasure safe and TJ gone, the friends set sail back home!" },
      { id: "homesweet", name: "Home Sweet Home", traits: ["Friendly", "Special"], emoji: "🏡", x: 88, y: 82, desc: "Papi and his friends return home. The best treasure of all is friendship and the adventures they share together!" }
    ]
  },
  3: {
    title: "The Ghost of Hound Manor",
    theme: "night",
    image: "images/maps/book3-map.jpg",
    locations: [
      { id: "home", name: "Papi's Home", traits: ["Friendly", "Special"], emoji: "🏠", x: 8, y: 28, desc: "Papi hears strange howls at night. He decides to investigate." },
      { id: "darkforest", name: "The Dark Forest", traits: ["Friendly", "Special"], emoji: "🌲", x: 28, y: 18, desc: "The friends enter the forest. The trees creak and shadows seem to move." },
      { id: "bridge", name: "The Old Bridge", traits: ["Friendly", "Special"], emoji: "🌉", x: 48, y: 12, desc: "The bridge is broken and the river below looks scary, but teamwork helps them cross!" },
      { id: "howling", name: "The Howling Hill", traits: ["Friendly", "Special"], emoji: "언덕", x: 72, y: 18, desc: "The howls get louder. Who—or what—is making them?" },
      { id: "moor", name: "The Foggy Moor", traits: ["Friendly", "Special"], emoji: "🌫️", x: 88, y: 38, desc: "A thick fog surrounds Hound Manor. The friends stay close together." },
      { id: "manor", name: "Hound Manor", traits: ["Friendly", "Special"], emoji: "🏚️", x: 48, y: 42, desc: "They arrive at the old manor. It looks spooky, but they take a deep breath and go in." },
      { id: "ghoststory", name: "The Ghost's Story", traits: ["Friendly", "Special"], emoji: "👻", x: 12, y: 58, desc: "It's not a scary ghost! He is the kind ghost of a dog who just wants his bone back." },
      { id: "truth", name: "The Hidden Truth", traits: ["Friendly", "Special"], emoji: "🦴", x: 35, y: 72, desc: "They find the missing bone! The ghost is grateful and the howling stops." },
      { id: "newfriend", name: "A New Friend", traits: ["Friendly", "Special"], emoji: "💙", x: 58, y: 78, desc: "The ghost thanks Papi and his friends. They promise to visit again." },
      { id: "homeagain", name: "Home Again", traits: ["Friendly", "Special"], emoji: "🌅", x: 85, y: 72, desc: "The friends return home, wiser and braver than before. Another adventure complete!" }
    ]
  },
  4: {
    title: "The Tomb of the Pharaoh",
    theme: "desert",
    image: "images/maps/book4-map.jpg",
    locations: [
      { id: "home", name: "Papi's Home", traits: ["Friendly", "Special"], emoji: "🏠", x: 8, y: 42, desc: "Papi hears about a hidden tomb filled with ancient treasures. He decides to begin the adventure!" },
      { id: "nile", name: "The Nile River", traits: ["Friendly", "Special"], emoji: "⛵", x: 32, y: 18, desc: "The friends sail down the Nile, enjoying the view and learning about Egypt's wonders." },
      { id: "pyramids", name: "The Great Pyramids", traits: ["Friendly", "Special"], emoji: "🔺", x: 58, y: 12, desc: "The pyramids rise high and tall. What mysteries could be hidden deep inside?" },
      { id: "sphinx", name: "The Sphinx", traits: ["Friendly", "Special"], emoji: "🦁", x: 88, y: 28, desc: "The Sphinx asks them riddles to test their wisdom and bravery." },
      { id: "sands", name: "The Shifting Sands", traits: ["Friendly", "Special"], emoji: "🏜️", x: 78, y: 52, desc: "The desert sands are tricky and always changing. Teamwork helps them cross safely!" },
      { id: "temple", name: "The Ancient Temple", traits: ["Friendly", "Special"], emoji: "🏛️", x: 48, y: 48, desc: "They find an old temple covered in hieroglyphs and hidden clues. Adventure awaits inside!" },
      { id: "tomb", name: "The Tomb Chamber", traits: ["Friendly", "Special"], emoji: "🔦", x: 38, y: 72, desc: "Inside the tomb, they face traps and puzzles to find the Pharaoh's treasure." },
      { id: "treasure", name: "The Pharaoh's Treasure", traits: ["Friendly", "Special"], emoji: "💎", x: 12, y: 62, desc: "The friends work together and find the treasure of the Pharaoh! But they know the real treasure is their friendship." },
      { id: "homeagain", name: "Home Again", traits: ["Friendly", "Special"], emoji: "🌅", x: 82, y: 82, desc: "The friends return home with hearts full of memories and lessons that will last forever." }
    ]
  },
  5: {
    title: "Mystery in the Australian Outback",
    theme: "outback",
    image: "images/maps/book5-map.jpg",
    locations: [
      { id: "home", name: "Papi's Home", traits: ["Friendly", "Special"], emoji: "🏠", x: 8, y: 38, desc: "Papi receives a mysterious message about a missing diamond in the Australian Outback." },
      { id: "plains", name: "The Red Kangaroo Plains", traits: ["Friendly", "Special"], emoji: "🦘", x: 32, y: 12, desc: "Papi meets Kim the Kangaroo, who shares how strange things have been happening in the Outback." },
      { id: "grove", name: "Cooper's Eucalyptus Grove", traits: ["Friendly", "Special"], emoji: "🐨", x: 52, y: 12, desc: "Cooper the Koala tells Papi about the thief who was seen near the old mining camp." },
      { id: "mining", name: "The Mining Camp", traits: ["Friendly", "Special"], emoji: "⛏️", x: 78, y: 18, desc: "Timothy the Tasmanian Devil has been causing mischief and searching for something valuable." },
      { id: "cave", name: "Brian's Rocky Cave", traits: ["Friendly", "Special"], emoji: "🦇", x: 88, y: 42, desc: "Brian the Bat saw Timothy heading toward the desert with a shiny diamond." },
      { id: "waterhole", name: "Peter's Waterhole", traits: ["Friendly", "Special"], emoji: "🦆", x: 68, y: 52, desc: "Peter the Platypus helps Papi cross the waterhole and offers a clue about the thief's hideout." },
      { id: "passage", name: "The Desert Passage", traits: ["Friendly", "Special"], emoji: "🏜️", x: 42, y: 42, desc: "The friends travel across the hot desert, facing tricky winds and shifting sands." },
      { id: "canyon", name: "Lookout Canyon", traits: ["Friendly", "Special"], emoji: "🪨", x: 12, y: 62, desc: "From the top, they spot the thief's hideout deep in the Winding Gorge." },
      { id: "hideout", name: "The Hideout", traits: ["Friendly", "Special"], emoji: "💎", x: 42, y: 78, desc: "The friends work together and outsmart Timothy, recovering the missing diamond!" },
      { id: "homeagain", name: "Home Again", traits: ["Friendly", "Special"], emoji: "🌅", x: 82, y: 82, desc: "Papi and his friends return home as heroes. Another adventure and mystery solved together!" }
    ]
  },
  6: {
    title: "The Magic of the Arctic",
    theme: "arctic",
    image: "images/maps/book6-map.jpg",
    locations: [
      { id: "call", name: "Papi and Oliver Hear the Call", traits: ["Friendly", "Special"], emoji: "🏠", x: 12, y: 42, desc: "Papi and Oliver are at home when they see a bright blue light in the sky. They know their friends might need help!" },
      { id: "flying", name: "Flying to the Arctic", traits: ["Friendly", "Special"], emoji: "✈️", x: 28, y: 18, desc: "Papi and Oliver fly in their plane towards the Arctic, following the mysterious blue light." },
      { id: "frozen", name: "The Frozen Arctic", traits: ["Friendly", "Special"], emoji: "❄️", x: 48, y: 12, desc: "When they arrive, they see the blue light everywhere. The Arctic is freezing, and the animals are worried." },
      { id: "newfriends", name: "New Friends", traits: ["Friendly", "Special"], emoji: "🦊", x: 82, y: 18, desc: "They meet Owen the Arctic Owl and Benny the Baby Seal. Benny tells them his Uncle went missing after the blue light appeared." },
      { id: "morefriends", name: "Meet More Friends", traits: ["Friendly", "Special"], emoji: "🐧", x: 88, y: 42, desc: "Papi and Oliver meet Peggy, Fred, Poppy, Winston, Harry and Wendy. Together they decide to find Benny's Uncle." },
      { id: "search", name: "Searching for Clues", traits: ["Friendly", "Special"], emoji: "🔍", x: 42, y: 48, desc: "The friends search across the icy lands, over frozen oceans and through snowy hills, looking for any clue about where Benny's Uncle went." },
      { id: "cave", name: "A Hidden Cave", traits: ["Friendly", "Special"], emoji: "🕳️", x: 12, y: 62, desc: "They find a hidden ice cave. Inside, they discover signs that Benny's Uncle was trying to stop the blue magic!" },
      { id: "stopping", name: "Stopping the Magic", traits: ["Friendly", "Special"], emoji: "✨", x: 38, y: 78, desc: "Working together, the friends use courage, kindness and friendship to stop the blue magic and melt the Arctic's ice." },
      { id: "warmth", name: "Warmth Returns", traits: ["Friendly", "Special"], emoji: "🌅", x: 58, y: 72, desc: "The blue light fades, the sun shines again, and the Arctic becomes warm. Everyone celebrates and Benny's Uncle is found safe!" },
      { id: "home", name: "Home Sweet Home", traits: ["Friendly", "Special"], emoji: "🏡", x: 88, y: 78, desc: "Papi and Oliver say goodbye to their Arctic friends and fly home, hearts full of wonderful memories." }
    ]
  }
};


