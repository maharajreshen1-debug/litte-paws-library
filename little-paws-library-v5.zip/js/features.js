/* Little Paws — extras: badges, quizzes, sound, read-aloud, parent */

const BADGES = [
  { id: "first-book", name: "First Adventure", emoji: "📖", desc: "Finish your first book", check: s => (s.completedBooks||[]).length >= 1 },
  { id: "all-books", name: "Library Hero", emoji: "🏆", desc: "Finish all 6 books", check: s => (s.completedBooks||[]).length >= 6 },
  { id: "friend-5", name: "Making Friends", emoji: "🤝", desc: "Unlock 5 characters", check: s => (s.unlockedCharacters||[]).length >= 5 },
  { id: "friend-all", name: "Every Friend", emoji: "💖", desc: "Unlock 20+ characters", check: s => (s.unlockedCharacters||[]).length >= 20 },
  { id: "stars-500", name: "Star Collector", emoji: "⭐", desc: "Earn 500 total stars (ever)", check: s => (s.lifetimeStars||0) >= 500 },
  { id: "stars-2000", name: "Star Master", emoji: "🌟", desc: "Earn 2000 lifetime stars", check: s => (s.lifetimeStars||0) >= 2000 },
  { id: "colour-3", name: "Little Artist", emoji: "🎨", desc: "Buy 3 colouring pages", check: s => (s.ownedColouring||[]).length >= 3 },
  { id: "duel-1", name: "First Cards", emoji: "🃏", desc: "Unlock 3 character cards", check: s => (s.unlockedCards||[]).length >= 3 },
  { id: "duel-5", name: "Card Collector", emoji: "🏅", desc: "Unlock 15 character cards", check: s => (s.unlockedCards||[]).length >= 15 },
  { id: "quiz-3", name: "Quiz Whiz", emoji: "🧠", desc: "Pass 3 book quizzes", check: s => (s.quizzesPassed||[]).length >= 3 },
  { id: "quiz-all", name: "Story Scholar", emoji: "🎓", desc: "Pass all 6 book quizzes", check: s => (s.quizzesPassed||[]).length >= 6 }
];

const QUIZZES = {
  1: {
    title: "Finding Home Quiz",
    questions: [
      { q: "What did Papi lose?", options: ["His bone", "His hat", "His map"], answer: 0 },
      { q: "Who helped Papi cross the river?", options: ["Felix", "Ollie the Otter", "Cora"], answer: 1 },
      { q: "What is the greatest treasure?", options: ["Gold", "Friendship", "A bigger bone"], answer: 1 },
      { q: "Who tried to trick Papi in the forest?", options: ["Toby", "Felix the Fox", "Bella"], answer: 1 },
      { q: "What did Papi learn at the end?", options: ["To stay home forever", "Friends and kindness are the real treasure", "Bones are the most important"], answer: 1 }
    ]
  },
  2: {
    title: "Puppy Island Quiz",
    questions: [
      { q: "Who wants the island treasure for himself?", options: ["Paulie", "TJ the Wolf", "Manny"], answer: 1 },
      { q: "What helps the friends cross the bridge?", options: ["Teamwork", "Magic only", "Flying"], answer: 0 },
      { q: "What is the real treasure?", options: ["Gold bones", "Friendship", "A ship"], answer: 1 },
      { q: "Who is the pirate parrot that gives clues?", options: ["TJ", "Paulie", "Tyson"], answer: 1 },
      { q: "How do the friends beat TJ?", options: ["By fighting alone", "With teamwork and cleverness", "By giving him the treasure"], answer: 1 }
    ]
  },
  3: {
    title: "Hound Manor Quiz",
    questions: [
      { q: "What were the strange sounds?", options: ["A scary monster", "A kind ghost dog", "Thunder"], answer: 1 },
      { q: "What did the ghost want?", options: ["His bone back", "To scare everyone", "Treasure"], answer: 0 },
      { q: "Courage means…", options: ["Never being afraid", "Facing fears with friends", "Running away"], answer: 1 },
      { q: "Who is the sneaky jackal causing trouble?", options: ["Billy", "Jackie", "Mike"], answer: 1 },
      { q: "What do the friends discover about the 'ghost'?", options: ["It is evil", "It is a kind dog who lost his bone", "It is just the wind"], answer: 1 }
    ]
  },
  4: {
    title: "Tomb of the Pharaoh Quiz",
    questions: [
      { q: "Who asks the friends riddles?", options: ["The Sphinx", "Brutus", "Cammy"], answer: 0 },
      { q: "What is the real treasure of the Pharaoh?", options: ["Gold only", "Friendship and family", "A camel"], answer: 1 },
      { q: "Who is the greedy villain?", options: ["Ralph", "Brutus", "Mystic"], answer: 1 },
      { q: "Who is the wise camel that helps in the desert?", options: ["Croco", "Cammy", "Baabi"], answer: 1 },
      { q: "What do the friends learn in the tomb?", options: ["Gold is everything", "True treasure is love of family and friends", "To be greedy"], answer: 1 }
    ]
  },
  5: {
    title: "Outback Mystery Quiz",
    questions: [
      { q: "What went missing in the Outback?", options: ["A diamond", "A map", "A plane"], answer: 0 },
      { q: "Who was causing mischief?", options: ["Cooper", "Timothy", "Kim"], answer: 1 },
      { q: "How do friends solve big mysteries?", options: ["Alone", "Together with kindness", "By giving up"], answer: 1 },
      { q: "Who is the detective platypus?", options: ["Kim", "Detective Peter", "Cooper"], answer: 1 },
      { q: "What is the best way to clear Sammy's name?", options: ["Blame someone else", "Find the truth with teamwork", "Run away"], answer: 1 }
    ]
  },
  6: {
    title: "Arctic Magic Quiz",
    questions: [
      { q: "What worried the Arctic animals?", options: ["A blue light / freeze", "Too much sun", "Rain"], answer: 0 },
      { q: "Who went missing?", options: ["Papi", "Benny's Uncle", "Wendy only"], answer: 1 },
      { q: "What melts the coldest ice?", options: ["Only fire", "Kindness & understanding", "Shouting"], answer: 1 },
      { q: "Who is the magical walrus?", options: ["Fred", "Winston", "Harry"], answer: 1 },
      { q: "What happens when Wendy joins the friends?", options: ["The ice gets worse", "The magic is freed and the Arctic warms", "Everyone gets scared forever"], answer: 1 }
    ]
  }
};

const DECK_PRESETS = {
  friends: { name: "Forest Friends", ids: ["papi","rosie","oliver","sammy","toby","bella","ollie","kindness-charm"] },
  villains: { name: "Villain Rush", ids: ["tj","andy","brutus","wendy","timothy","brian","dan","tj-ambush"] },
  maps: { name: "Map Master", ids: ["papi","oliver","map-book1","map-book2","map-book4","map-book6","kindness-charm","loyal-bark"] },
  island: { name: "Island Crew", ids: ["papi","paulie","tyson","manny","tj","golden-bones","pirate-flag","vine-swing"] },
  arctic: { name: "Arctic Magic", ids: ["papi","owen","peggy","winston","wendy","map-book6","arctic-staff","snow-storm"] }
};

let soundEnabled = localStorage.getItem("papiSound") !== "off";
let audioCtx = null;

function ensureAudio() {
  if (!audioCtx) {
    try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch(e) {}
  }
  return audioCtx;
}

function playTone(freq, dur, type, vol) {
  if (!soundEnabled) return;
  const ctx = ensureAudio();
  if (!ctx) return;
  try {
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type || "sine";
    o.frequency.value = freq;
    g.gain.value = vol || 0.08;
    o.connect(g); g.connect(ctx.destination);
    o.start();
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + (dur||0.15));
    o.stop(ctx.currentTime + (dur||0.15) + 0.02);
  } catch(e) {}
}

function sfx(name) {
  if (!soundEnabled) return;
  if (name === "star") { playTone(880, 0.12, "sine", 0.1); setTimeout(() => playTone(1175, 0.15, "sine", 0.08), 80); }
  else if (name === "page") playTone(520, 0.08, "triangle", 0.06);
  else if (name === "unlock") { playTone(660, 0.1); setTimeout(() => playTone(880, 0.12), 100); setTimeout(() => playTone(1320, 0.2), 200); }
  else if (name === "hit") playTone(180, 0.12, "square", 0.05);
  else if (name === "win") { playTone(523, 0.12); setTimeout(() => playTone(659, 0.12), 120); setTimeout(() => playTone(784, 0.25), 240); }
  else if (name === "click") playTone(400, 0.05, "sine", 0.04);
}

function toggleSound() {
  soundEnabled = !soundEnabled;
  localStorage.setItem("papiSound", soundEnabled ? "on" : "off");
  const btn = document.getElementById("soundToggle");
  if (btn) btn.textContent = soundEnabled ? "🔊 Sound" : "🔇 Muted";
  sfx("click");
}

function checkBadges() {
  if (!state.badges) state.badges = [];
  let newOnes = [];
  BADGES.forEach(b => {
    if (!state.badges.includes(b.id) && b.check(state)) {
      state.badges.push(b.id);
      newOnes.push(b);
    }
  });
  if (newOnes.length) {
    saveState();
    sfx("unlock");
    const names = newOnes.map(b => `${b.emoji} ${b.name}`).join(", ");
    showToast(`Badge unlocked: ${names}`);
  }
}

function showToast(msg) {
  let t = document.getElementById("papiToast");
  if (!t) {
    t = document.createElement("div");
    t.id = "papiToast";
    t.className = "papi-toast";
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 3200);
}

function renderBadges() {
  const el = document.getElementById("badgesGrid");
  if (!el) return;
  const earned = state.badges || [];
  el.innerHTML = BADGES.map(b => {
    const has = earned.includes(b.id);
    return `<div class="badge-card ${has ? "earned" : "locked"}">
      <div class="badge-emoji">${has ? b.emoji : "🔒"}</div>
      <div class="badge-name">${b.name}</div>
      <div class="badge-desc">${b.desc}</div>
    </div>`;
  }).join("");
}

function renderParent() {
  const el = document.getElementById("parentPanel");
  if (!el) return;
  const books = (typeof BOOKS !== "undefined" ? BOOKS : []).map(b => {
    const done = (state.completedBooks||[]).includes(b.id);
    return `<li>${done ? "✅" : "⬜"} ${b.title || b.shortTitle || ("Book "+b.id)}</li>`;
  }).join("");
  el.innerHTML = `
    <div class="parent-stats">
      <div><strong>⭐ Stars:</strong> ${state.stars||0}</div>
      <div><strong>Lifetime stars:</strong> ${state.lifetimeStars||0}</div>
      <div><strong>Characters unlocked:</strong> ${(state.unlockedCharacters||[]).length}</div>
      <div><strong>Colouring unlocked:</strong> ${(state.ownedColouring||[]).length}</div>
      <div><strong>Duel wins:</strong> ${state.duelWins||0}</div>
      <div><strong>Badges:</strong> ${(state.badges||[]).length} / ${BADGES.length}</div>
      <div><strong>Quizzes passed:</strong> ${(state.quizzesPassed||[]).length} / 6</div>
    </div>
    <h4>Books</h4>
    <ul class="parent-books">${books}</ul>
    <button class="btn btn-secondary" onclick="setupParentPin()">🔐 Set / change Parent PIN</button>
    <button class="btn btn-secondary" onclick="resetChildProgress()">Reset this child's progress</button>
    <p class="muted" style="margin-top:0.5rem;font-size:0.85rem;">PIN protects reset. Leave unset for no lock.</p>
  `;
}

function resetChildProgress() {
  if (!confirm("Reset stars, unlocks, badges and progress for this device?")) return;
  state.stars = 0;
  state.lifetimeStars = 0;
  state.unlockedCharacters = [];
  state.ownedColouring = [];
  state.completedBooks = [];
  state.bookProgress = {};
  state.badges = [];
  state.duelWins = 0;
  state.quizzesPassed = [];
  saveState();
  showToast("Progress reset");
  renderParent();
  if (typeof updateStarsDisplay === "function") updateStarsDisplay();
}

/* ---- Quizzes ---- */
let quizState = { bookId: null, idx: 0, score: 0 };

function openQuiz(bookId) {
  if (!(state.completedBooks||[]).includes(bookId)) {
    showToast("Finish the book first to take its quiz!");
    return;
  }
  const quiz = QUIZZES[bookId];
  if (!quiz) return;
  quizState = { bookId, idx: 0, score: 0 };
  document.getElementById("quizModal")?.classList.remove("hidden");
  renderQuizQuestion();
}

function renderQuizQuestion() {
  const quiz = QUIZZES[quizState.bookId];
  const box = document.getElementById("quizBody");
  if (!quiz || !box) return;
  if (quizState.idx >= quiz.questions.length) {
    finishQuiz();
    return;
  }
  const q = quiz.questions[quizState.idx];
  box.innerHTML = `
    <h3>${quiz.title}</h3>
    <p class="quiz-progress">Question ${quizState.idx+1} of ${quiz.questions.length}</p>
    <p class="quiz-q">${q.q}</p>
    <div class="quiz-options">
      ${q.options.map((o,i) => `<button class="btn quiz-opt" onclick="answerQuiz(${i})">${o}</button>`).join("")}
    </div>`;
}

function answerQuiz(i) {
  const q = QUIZZES[quizState.bookId].questions[quizState.idx];
  if (i === q.answer) {
    quizState.score++;
    sfx("star");
    showToast("Correct! ⭐");
  } else {
    sfx("hit");
    showToast("Not quite — keep going!");
  }
  quizState.idx++;
  setTimeout(renderQuizQuestion, 400);
}

function finishQuiz() {
  const total = QUIZZES[quizState.bookId].questions.length;
  const passed = quizState.score >= Math.ceil(total * 0.66);
  const box = document.getElementById("quizBody");
  let bonus = 0;
  if (passed) {
    if (!(state.quizzesPassed||[]).includes(quizState.bookId)) {
      if (!state.quizzesPassed) state.quizzesPassed = [];
      state.quizzesPassed.push(quizState.bookId);
      bonus = 150;
      state.stars = (state.stars||0) + bonus;
      state.lifetimeStars = (state.lifetimeStars||0) + bonus;
      saveState();
      checkBadges();
      sfx("win");
    }
  }
  box.innerHTML = `
    <h3>Quiz complete!</h3>
    <p>You got <strong>${quizState.score}/${total}</strong>.</p>
    <p>${passed ? (bonus ? `Great job! +${bonus} ⭐` : "You already earned the bonus for this quiz.") : "Try again after rereading the story for stars!"}</p>
    <button class="btn btn-primary" onclick="closeQuiz()">Close</button>`;
  if (typeof updateStarsDisplay === "function") updateStarsDisplay();
}

function closeQuiz() {
  document.getElementById("quizModal")?.classList.add("hidden");
}

/* ---- Read aloud (improved) ---- */
let speaking = false;
let readAloudRate = parseFloat(localStorage.getItem("papiReadRate") || "0.85");
let currentUtterance = null;
let highlightEl = null;

function getPreferredVoice() {
  const voices = speechSynthesis.getVoices();
  if (!voices || !voices.length) return null;
  // Prefer gentle/clear English voices suitable for children
  const preferred = [
    /samantha/i, /karen/i, /moira/i, /tessa/i, /fiona/i,
    /google uk english female/i, /google us english/i,
    /microsoft zira/i, /microsoft hazel/i, /female/i
  ];
  for (const re of preferred) {
    const v = voices.find(x => re.test(x.name) && /en/i.test(x.lang));
    if (v) return v;
  }
  // Fallback: any English voice
  return voices.find(v => /en/i.test(v.lang)) || voices[0];
}

function clearHighlight() {
  if (highlightEl) {
    highlightEl.classList.remove("read-aloud-highlight");
    highlightEl = null;
  }
  document.querySelectorAll(".read-aloud-highlight").forEach(el => el.classList.remove("read-aloud-highlight"));
}

function readAloud(text, options = {}) {
  if (!window.speechSynthesis) {
    if (typeof showToast === "function") showToast("Read-aloud not supported on this device");
    return;
  }
  if (speaking) {
    speechSynthesis.cancel();
    speaking = false;
    currentUtterance = null;
    clearHighlight();
    document.querySelectorAll(".btn-readaloud").forEach(b => b.textContent = "🔊 Listen");
    return;
  }
  speechSynthesis.cancel();
  clearHighlight();

  const u = new SpeechSynthesisUtterance(text);
  u.rate = readAloudRate;
  u.pitch = 1.05;
  u.volume = 1;

  // Try to pick a nice voice (voices may load async)
  const applyVoice = () => {
    const voice = getPreferredVoice();
    if (voice) u.voice = voice;
  };
  applyVoice();
  if (speechSynthesis.getVoices().length === 0) {
    speechSynthesis.onvoiceschanged = () => { applyVoice(); };
  }

  // Highlight the chapter text block while speaking
  const textEl = document.querySelector(".chapter-text, #readerText, .reader-text");
  if (textEl) {
    textEl.classList.add("read-aloud-highlight");
    highlightEl = textEl;
  }

  speaking = true;
  currentUtterance = u;
  u.onend = () => {
    speaking = false;
    currentUtterance = null;
    clearHighlight();
    document.querySelectorAll(".btn-readaloud").forEach(b => b.textContent = "🔊 Listen");
  };
  u.onerror = () => {
    speaking = false;
    currentUtterance = null;
    clearHighlight();
    document.querySelectorAll(".btn-readaloud").forEach(b => b.textContent = "🔊 Listen");
  };
  speechSynthesis.speak(u);
  document.querySelectorAll(".btn-readaloud").forEach(b => b.textContent = "⏹ Stop");
  if (typeof sfx === "function") sfx("click");
}

function setReadAloudRate(rate) {
  readAloudRate = rate;
  localStorage.setItem("papiReadRate", String(rate));
  if (typeof showToast === "function") {
    const label = rate <= 0.75 ? "Slow" : rate >= 1.0 ? "Normal" : "Gentle";
    showToast("Read speed: " + label);
  }
  updateReadSpeedBtn();
}

function cycleReadSpeed() {
  // Cycle: Gentle (0.85) → Slow (0.7) → Normal (1.0) → Gentle
  if (readAloudRate <= 0.75) setReadAloudRate(1.0);
  else if (readAloudRate >= 0.95) setReadAloudRate(0.85);
  else setReadAloudRate(0.7);
}

function updateReadSpeedBtn() {
  const btn = document.getElementById("readSpeedBtn");
  if (!btn) return;
  if (readAloudRate <= 0.75) btn.textContent = "🐢 Slow";
  else if (readAloudRate >= 0.95) btn.textContent = "🐇 Normal";
  else btn.textContent = "🐾 Gentle";
}

function readCurrentChapter() {
  // Prefer visible chapter text from BOOKS data
  if (typeof state !== "undefined" && state.currentBookId && typeof BOOKS !== "undefined") {
    const book = BOOKS.find(b => b.id === state.currentBookId);
    const ch = book && book.chapters && book.chapters[state.currentChapter];
    if (ch) {
      readAloud(`${ch.title}. ${ch.text}`);
      return;
    }
  }
  const textEl = document.getElementById("readerText") || document.querySelector(".reader-text, .chapter-text, #chapterContent");
  if (textEl && textEl.textContent.trim()) readAloud(textEl.textContent);
  else if (typeof showToast === "function") showToast("Open a chapter to listen");
}

/* ---- Print colouring ---- */
function printColouringPack() {
  const pages = typeof COLOURING_PAGES !== "undefined" ? COLOURING_PAGES : [];
  const w = window.open("", "_blank");
  if (!w) { showToast("Please allow pop-ups to print"); return; }
  const imgs = pages.map(p => `<div class="sheet"><h2>${p.title}</h2><img src="${p.image}" style="max-width:100%;max-height:85vh;"></div>`).join("");
  w.document.write(`<!DOCTYPE html><html><head><title>Little Paws Colouring Pack</title>
    <style>body{font-family:sans-serif}.sheet{page-break-after:always;text-align:center;padding:1rem}h2{color:#e67e22}</style>
    </head><body><h1>Little Paws Library — Colouring Pack</h1>${imgs}
    <script>window.onload=()=>setTimeout(()=>window.print(),500)<\/script></body></html>`);
  w.document.close();
}

/* ---- Deck presets ---- */
function applyDeckPreset(key) {
  const preset = DECK_PRESETS[key];
  if (!preset || typeof tcgState === "undefined") return;
  const owned = typeof tcgOwnedCards === "function" ? tcgOwnedCards().map(c => c.id) : preset.ids;
  tcgState.deck = preset.ids.filter(id => owned.includes(id) || id.startsWith("map-") || true).slice(0, 8);
  // pad if needed
  while (tcgState.deck.length < 8 && owned.length) {
    const id = owned[tcgState.deck.length % owned.length];
    if (!tcgState.deck.includes(id)) tcgState.deck.push(id);
    else break;
  }
  if (typeof tcgRenderDeckBuilder === "function") tcgRenderDeckBuilder();
  showToast(`Deck: ${preset.name}`);
  sfx("click");
}

function awardDuelStars(won) {
  if (!won) return;
  state.duelWins = (state.duelWins || 0) + 1;
  const gain = 75;
  state.stars = (state.stars || 0) + gain;
  state.lifetimeStars = (state.lifetimeStars || 0) + gain;
  saveState();
  checkBadges();
  if (typeof updateStarsDisplay === "function") updateStarsDisplay();
  showToast(`Duel win! +${gain} ⭐`);
  sfx("win");
}

// Hook stars when earning elsewhere
function trackLifetimeStars(amount) {
  if (amount > 0) {
    state.lifetimeStars = (state.lifetimeStars || 0) + amount;
    checkBadges();
  }
}

/* ---- Daily bonus, sets, onboarding, album, continue ---- */
const CARD_SETS = [
  { id: "book1", name: "Forest Friends", book: 1, bonus: 100, ids: null },
  { id: "book2", name: "Puppy Island", book: 2, bonus: 100, ids: null },
  { id: "book3", name: "Hound Manor", book: 3, bonus: 100, ids: null },
  { id: "book4", name: "Egypt Adventures", book: 4, bonus: 120, ids: null },
  { id: "book5", name: "Outback Heroes", book: 5, bonus: 120, ids: null },
  { id: "book6", name: "Arctic Magic", book: 6, bonus: 120, ids: null },
  { id: "villains", name: "All Villains", book: null, bonus: 150, villain: true }
];

function cardRarity(c) {
  const cost = c.cost || 50;
  if (cost >= 500 || c.id === "papi") return "legendary";
  if (cost >= 300 || c.isVillain) return "epic";
  if (cost >= 150) return "rare";
  return "common";
}

function claimDailyBonus() {
  const key = "papiDailyBonus";
  const today = new Date().toISOString().slice(0, 10);
  const last = localStorage.getItem(key);
  const banner = document.getElementById("dailyBonusBanner");
  if (last === today) {
    if (banner) banner.classList.add("hidden");
    return false;
  }
  if (!state) return false;
  state.stars = (state.stars || 0) + 50;
  state.lifetimeStars = (state.lifetimeStars || 0) + 50;
  localStorage.setItem(key, today);
  if (typeof saveState === "function") saveState();
  if (typeof updateStarsDisplay === "function") updateStarsDisplay();
  if (typeof updateHomeStars === "function") updateHomeStars();
  if (typeof sfx === "function") sfx("star");
  if (typeof showToast === "function") showToast("Daily bonus! +50 ⭐");
  if (typeof checkBadges === "function") checkBadges();
  if (banner) banner.classList.add("hidden");
  return true;
}

function showDailyBannerIfNeeded() {
  const today = new Date().toISOString().slice(0, 10);
  const last = localStorage.getItem("papiDailyBonus");
  const banner = document.getElementById("dailyBonusBanner");
  if (!banner) return;
  if (last === today) banner.classList.add("hidden");
  else banner.classList.remove("hidden");
}

function checkSetCompletion(justUnlockedId) {
  if (!state.unlockedCards) state.unlockedCards = [];
  if (!state.setBonusesClaimed) state.setBonusesClaimed = [];
  if (typeof CHARACTERS === "undefined") return;

  CARD_SETS.forEach(set => {
    if (state.setBonusesClaimed.includes(set.id)) return;
    let members;
    if (set.villain) members = CHARACTERS.filter(c => c.isVillain);
    else members = CHARACTERS.filter(c => c.book === set.book);
    if (!members.length) return;
    const allOwned = members.every(c => state.unlockedCards.includes(c.id));
    if (allOwned) {
      state.setBonusesClaimed.push(set.id);
      state.stars = (state.stars || 0) + set.bonus;
      state.lifetimeStars = (state.lifetimeStars || 0) + set.bonus;
      if (typeof saveState === "function") saveState();
      if (typeof updateStarsDisplay === "function") updateStarsDisplay();
      if (typeof sfx === "function") sfx("win");
      if (typeof showToast === "function") showToast(`Set complete: ${set.name}! +${set.bonus} ⭐`);
      if (typeof checkBadges === "function") checkBadges();
    }
  });
}

function renderContinueReading() {
  const el = document.getElementById("continueReading");
  if (!el || typeof BOOKS === "undefined") return;
  // Find in-progress book (has progress but not complete)
  let best = null;
  BOOKS.forEach(b => {
    const prog = state.bookProgress && state.bookProgress[b.id];
    const done = (state.completedBooks || []).includes(b.id);
    if (!done && prog != null && prog >= 0) {
      best = { book: b, chapter: prog };
    }
  });
  // Or last opened
  if (!best && state.currentBookId) {
    const b = BOOKS.find(x => x.id === state.currentBookId);
    const done = b && (state.completedBooks || []).includes(b.id);
    if (b && !done) best = { book: b, chapter: state.bookProgress[b.id] ?? 0 };
  }
  if (!best) {
    el.innerHTML = "";
    el.classList.add("hidden");
    return;
  }
  el.classList.remove("hidden");
  const ch = (best.chapter || 0) + 1;
  el.innerHTML = `
    <div class="continue-card">
      <div class="continue-text">
        <span class="continue-label">Continue reading</span>
        <strong>${best.book.emoji || "📘"} ${best.book.shortTitle || best.book.title}</strong>
        <span>Chapter ${ch} of ${best.book.chapters.length}</span>
      </div>
      <button class="btn btn-primary" onclick="openBook(${best.book.id})">Continue →</button>
    </div>`;
}

function renderMyAlbum() {
  const grid = document.getElementById("albumGrid");
  if (!grid || typeof CHARACTERS === "undefined") return;
  const owned = (state.unlockedCards || [])
    .map(id => CHARACTERS.find(c => c.id === id))
    .filter(Boolean);
  const empty = document.getElementById("albumEmpty");
  if (empty) empty.style.display = owned.length ? "none" : "block";
  grid.innerHTML = owned.map(c => {
    const rarity = cardRarity(c);
    return `<button class="album-card rarity-${rarity}" onclick="viewCard('${c.id}')">
      <img src="${c.card || ""}" alt="${c.name}" onerror="this.style.display='none'">
      <span class="album-name">${c.name}</span>
      <span class="rarity-tag">${rarity}</span>
    </button>`;
  }).join("");
}

function renderWallOfFame() {
  const el = document.getElementById("wallOfFame");
  if (!el) return;
  const books = (state.completedBooks || []).length;
  const cards = (state.unlockedCards || []).length;
  const badges = (state.badges || []).length;
  const totalC = typeof CHARACTERS !== "undefined" ? CHARACTERS.length : 0;
  el.innerHTML = `
    <div class="wall-item"><span class="wall-num">${books}/6</span><span>Books</span></div>
    <div class="wall-item"><span class="wall-num">${cards}/${totalC}</span><span>Cards</span></div>
    <div class="wall-item"><span class="wall-num">${badges}</span><span>Badges</span></div>
    <div class="wall-item"><span class="wall-num">${state.lifetimeStars || 0}</span><span>Lifetime ⭐</span></div>`;
}

function showWelcomeGateIfNeeded() {
  // Show gate if no child name has been set yet
  const name = localStorage.getItem("papiReaderName");
  const gate = document.getElementById("welcomeGate");
  if (!gate) return;
  if (name && name.trim() && name !== "Little Reader") {
    gate.classList.add("hidden");
  } else {
    gate.classList.remove("hidden");
    // Pre-fill if a name somehow exists
    const input = document.getElementById("welcomeChildName");
    if (input && name && name !== "Little Reader") input.value = name;
  }
}

function completeWelcomeGate() {
  const nameInput = document.getElementById("welcomeChildName");
  const pinInput = document.getElementById("welcomePin");
  const name = (nameInput?.value || "").trim();

  if (!name || name.length < 1) {
    if (typeof showToast === "function") showToast("Please enter the child’s name");
    nameInput?.focus();
    return;
  }

  // Save child name
  localStorage.setItem("papiReaderName", name);

  // Optional Parent PIN
  const pin = (pinInput?.value || "").trim();
  if (pin) {
    if (!/^\d{4}$/.test(pin)) {
      if (typeof showToast === "function") showToast("PIN must be 4 digits");
      pinInput?.focus();
      return;
    }
    localStorage.setItem("papiParentPin", pin);
  }

  // Mark as completed
  localStorage.setItem("papiOnboarded", "1");

  // Hide the gate
  document.getElementById("welcomeGate")?.classList.add("hidden");

  if (typeof sfx === "function") sfx("win");
  if (typeof showToast === "function") showToast("Welcome, " + name + "! 🎉");
  if (typeof updateFreeCardBanner === "function") updateFreeCardBanner();
  if (typeof showSection === "function") showSection("home");
}

// Keep old name for compatibility
function showOnboardingIfNeeded() {
  showWelcomeGateIfNeeded();
}
function finishOnboarding() {
  completeWelcomeGate();
}

function toggleNightMode() {
  document.body.classList.toggle("night-mode");
  localStorage.setItem("papiNight", document.body.classList.contains("night-mode") ? "1" : "0");
}

function toggleLargeText() {
  document.body.classList.toggle("large-text");
  localStorage.setItem("papiLargeText", document.body.classList.contains("large-text") ? "1" : "0");
}

function applyReaderPrefs() {
  if (localStorage.getItem("papiNight") === "1") document.body.classList.add("night-mode");
  if (localStorage.getItem("papiLargeText") === "1") document.body.classList.add("large-text");
}

document.addEventListener("DOMContentLoaded", () => {
  applyReaderPrefs();
  showDailyBannerIfNeeded();
  showOnboardingIfNeeded();

  // Allow Enter key on the welcome form
  const nameInput = document.getElementById("welcomeChildName");
  const pinInput = document.getElementById("welcomePin");
  [nameInput, pinInput].forEach(el => {
    if (el) el.addEventListener("keydown", (e) => {
      if (e.key === "Enter") completeWelcomeGate();
    });
  });

  setTimeout(() => {
    if (typeof renderContinueReading === "function") renderContinueReading();
    if (typeof renderWallOfFame === "function") renderWallOfFame();
  }, 200);
});


/* ---- Search, PIN, favourite, celebration, maps visited ---- */
function setFavouriteCard(id) {
  state.favouriteCard = id;
  if (typeof saveState === "function") saveState();
  if (typeof showToast === "function") showToast("Favourite friend updated!");
  if (typeof sfx === "function") sfx("click");
  renderFavouriteCard();
}

function renderFavouriteCard() {
  const el = document.getElementById("favouriteCardHome");
  if (!el || typeof CHARACTERS === "undefined") return;
  const id = state.favouriteCard;
  const c = id && CHARACTERS.find(x => x.id === id);
  const owned = (state.unlockedCards || []);
  if (!c || !owned.includes(c.id)) {
    // pick first owned or prompt
    const first = owned.map(i => CHARACTERS.find(x => x.id === i)).find(Boolean);
    if (!first) {
      el.innerHTML = `<div class="fav-empty">Unlock a card, then set a favourite on its View screen.</div>`;
      return;
    }
    el.innerHTML = `
      <button class="fav-card-btn" onclick="viewCard('${first.id}')">
        <img src="${first.card||""}" alt="${first.name}" onerror="this.style.display='none'">
        <div><span class="fav-label">Friend spotlight</span><strong>${first.name}</strong></div>
      </button>`;
    return;
  }
  el.innerHTML = `
    <button class="fav-card-btn" onclick="viewCard('${c.id}')">
      <img src="${c.card||""}" alt="${c.name}" onerror="this.style.display='none'">
      <div><span class="fav-label">Your favourite</span><strong>${c.name}</strong></div>
    </button>`;
}

function celebrateBookFinish(book) {
  const overlay = document.getElementById("celebrateOverlay");
  if (!overlay) return;
  const title = book ? (book.shortTitle || book.title) : "Adventure";
  overlay.innerHTML = `
    <div class="celebrate-box">
      <div class="celebrate-confetti" aria-hidden="true">${"🎉⭐🌟✨🏆".repeat(8)}</div>
      <h2>Book complete!</h2>
      <p>You finished <strong>${title}</strong></p>
      <p class="celebrate-stars">You're a Little Paws hero!</p>
      <div class="celebrate-actions">
        <button class="btn btn-primary" onclick="closeCelebrate(); showBookCertificate(${book ? book.id : 0})">🎓 View Certificate</button>
        <button class="btn btn-secondary" onclick="closeCelebrate(); showSection('cards')">🃏 Collect cards</button>
        ${(book && (state.completedBooks||[]).includes(book.id)) ? `<button class="btn btn-secondary" onclick="closeCelebrate(); openQuiz(${book.id})">🧠 Take quiz</button>` : ""}
        <button class="btn btn-secondary" onclick="closeCelebrate(); showSection('home')">Home</button>
      </div>
    </div>`;
  overlay.classList.remove("hidden");
  if (typeof sfx === "function") sfx("win");
}

function showBookCertificate(bookId) {
  const book = (typeof BOOKS !== "undefined") && BOOKS.find(b => b.id === bookId);
  if (!book) return;
  const m = document.getElementById("bookCertModal");
  if (!m) return;
  const name = localStorage.getItem("papiReaderName") || "Little Reader";
  document.getElementById("bookCertName").textContent = name;
  document.getElementById("bookCertTitle").textContent = book.emoji + " " + (book.title || book.shortTitle);
  document.getElementById("bookCertMoral").textContent = "“" + (book.moral || "Friendship and kindness are the greatest treasures of all.") + "”";
  const input = document.getElementById("bookCertNameInput");
  if (input) input.value = name === "Little Reader" ? "" : name;
  m.classList.remove("hidden");
  if (typeof sparkleCenter === "function") sparkleCenter(20);
  if (typeof sfx === "function") sfx("win");
}

function closeBookCert() {
  document.getElementById("bookCertModal")?.classList.add("hidden");
}

function saveBookCertName() {
  const v = document.getElementById("bookCertNameInput")?.value?.trim();
  if (v) {
    localStorage.setItem("papiReaderName", v);
    const el = document.getElementById("bookCertName");
    if (el) el.textContent = v;
  }
}

function printBookCert() {
  saveBookCertName();
  // Temporarily hide the graduate modal print styles conflict
  const grad = document.getElementById("graduateCertPrint");
  if (grad) grad.style.display = "none";
  window.print();
  setTimeout(() => { if (grad) grad.style.display = ""; }, 500);
}

function closeCelebrate() {
  document.getElementById("celebrateOverlay")?.classList.add("hidden");
}

function getParentPin() {
  return localStorage.getItem("papiParentPin") || "";
}

function setupParentPin() {
  const existing = getParentPin();
  if (existing) {
    const cur = prompt("Enter current Parent PIN to change it:");
    if (cur !== existing) { if (typeof showToast === "function") showToast("Wrong PIN"); return; }
  }
  const pin = prompt("Set a 4-digit Parent PIN (used to reset progress):");
  if (!pin || !/^\d{4}$/.test(pin)) {
    if (typeof showToast === "function") showToast("PIN must be 4 digits");
    return;
  }
  localStorage.setItem("papiParentPin", pin);
  if (typeof showToast === "function") showToast("Parent PIN saved");
}

function parentPinGate(actionLabel) {
  const pin = getParentPin();
  if (!pin) return true; // no pin set
  const entered = prompt(`Parent PIN required to ${actionLabel}:`);
  if (entered !== pin) {
    if (typeof showToast === "function") showToast("Incorrect PIN");
    return false;
  }
  return true;
}

// wrap reset
const _origResetChild = typeof resetChildProgress === "function" ? resetChildProgress : null;
function resetChildProgress() {
  if (!parentPinGate("reset progress")) return;
  if (!confirm("Reset stars, unlocks, badges and progress for this device?")) return;
  state.stars = 0;
  state.lifetimeStars = 0;
  state.unlockedCharacters = [];
  state.ownedColouring = [];
  state.unlockedCards = [];
  state.completedBooks = [];
  state.bookProgress = {};
  state.badges = [];
  state.duelWins = 0;
  state.quizzesPassed = [];
  state.setBonusesClaimed = [];
  state.favouriteCard = null;
  state.visitedMaps = [];
  if (typeof saveState === "function") saveState();
  if (typeof showToast === "function") showToast("Progress reset");
  if (typeof renderParent === "function") renderParent();
  if (typeof updateStarsDisplay === "function") updateStarsDisplay();
}

function markMapVisited(bookId) {
  if (!state.visitedMaps) state.visitedMaps = [];
  if (!state.visitedMaps.includes(bookId)) {
    state.visitedMaps.push(bookId);
    if (typeof saveState === "function") saveState();
  }
}

function filterCardsSearch() {
  const q = (document.getElementById("cardSearch")?.value || "").trim().toLowerCase();
  window._cardSearchQ = q;
  if (typeof renderCardCollection === "function") renderCardCollection();
}

/* ========== AMAZING BATCH ========== */
const PAPI_TIPS = [
  "Let's earn stars by reading a chapter today!",
  "Have you explored the Story Maps yet?",
  "Unlock a new friend for your card album!",
  "Colour a page — it's fun and earns stars!",
  "Finished a book? Try its quiz for bonus stars!",
  "Complete a whole card set for a big star bonus!",
  "Pick a favourite friend to show on Home!",
  "The Arctic awaits when you're ready for Book 6!",
  "Kindness is the greatest magic of all.",
  "Together we can do anything — one heart!"
];

function renderPapiTip() {
  const el = document.getElementById("papiTipBubble");
  if (!el) return;
  const done = (state.completedBooks || []).length;
  let tip;
  if (done >= 6) tip = "You finished every adventure! You're a true Little Paws Graduate! 🎓";
  else if (done === 0) tip = "Hi! I'm Papi — start with Book 1 to earn your first stars! ⭐";
  else if ((state.unlockedCards || []).length < 3) tip = "Read more chapters, then unlock cards for your album!";
  else tip = PAPI_TIPS[Math.floor(Math.random() * PAPI_TIPS.length)];
  el.innerHTML = `
    <div class="papi-tip">
      <div class="papi-tip-avatar">🐾</div>
      <div class="papi-tip-text">
        <strong>Papi says…</strong>
        <p>${tip}</p>
      </div>
      <button type="button" class="papi-tip-refresh" onclick="renderPapiTip()" title="New tip">🔄</button>
    </div>`;
}

function sparkleBurst(x, y, count) {
  const layer = document.getElementById("sparkleLayer");
  if (!layer) return;
  const n = count || 18;
  const symbols = ["✨", "⭐", "🌟", "💫", "✦"];
  for (let i = 0; i < n; i++) {
    const s = document.createElement("span");
    s.className = "sparkle-particle";
    s.textContent = symbols[i % symbols.length];
    const angle = (Math.PI * 2 * i) / n;
    const dist = 40 + Math.random() * 80;
    s.style.left = (x || window.innerWidth / 2) + "px";
    s.style.top = (y || window.innerHeight / 3) + "px";
    s.style.setProperty("--dx", Math.cos(angle) * dist + "px");
    s.style.setProperty("--dy", Math.sin(angle) * dist + "px");
    s.style.animationDelay = (Math.random() * 0.15) + "s";
    layer.appendChild(s);
    setTimeout(() => s.remove(), 1200);
  }
}

function sparkleCenter(count) {
  sparkleBurst(window.innerWidth / 2, window.innerHeight * 0.35, count || 22);
}

function enhancedCelebrate(book) {
  sparkleCenter(28);
  if (typeof celebrateBookFinish === "function") {
    /* original will show overlay */
  }
  // Map sticker
  if (book && book.id) {
    if (!state.mapStickers) state.mapStickers = [];
    if (!state.mapStickers.includes(book.id)) {
      state.mapStickers.push(book.id);
      if (typeof saveState === "function") saveState();
    }
  }
  // Graduate?
  if ((state.completedBooks || []).length >= 6) {
    setTimeout(() => showGraduateCertificate(), 900);
  }
}

const MAP_STICKERS = {
  1: "🦴", 2: "🏝️", 3: "🌙", 4: "🗝️", 5: "💎", 6: "❄️"
};

function getMapSticker(bookId) {
  if ((state.mapStickers || []).includes(bookId) || (state.completedBooks || []).includes(bookId)) {
    return MAP_STICKERS[bookId] || "⭐";
  }
  return null;
}

function showGraduateCertificate() {
  const m = document.getElementById("graduateModal");
  if (!m) return;
  const name = localStorage.getItem("papiReaderName") || "Little Reader";
  document.getElementById("gradName").textContent = name;
  const input = document.getElementById("gradNameInput");
  if (input) input.value = name === "Little Reader" ? "" : name;
  m.classList.remove("hidden");
  if (typeof sparkleCenter === "function") sparkleCenter(30);
  if (typeof sfx === "function") sfx("win");
}

function closeGraduate() {
  document.getElementById("graduateModal")?.classList.add("hidden");
}

function saveGradName() {
  const v = document.getElementById("gradNameInput")?.value?.trim();
  if (v) {
    localStorage.setItem("papiReaderName", v);
    const el = document.getElementById("gradName");
    if (el) el.textContent = v;
  }
}

function printCertificate() {
  saveGradName();
  window.print();
}

/* Flip card view */
function viewCardFlip(id) {
  const c = (typeof CHARACTERS !== "undefined") && CHARACTERS.find(x => x.id === id);
  if (!c) return;
  const modal = document.getElementById("cardViewModal");
  const body = document.getElementById("cardViewBody");
  if (!modal || !body) return;
  const rarity = typeof cardRarity === "function" ? cardRarity(c) : "common";
  const shiny = rarity === "legendary" || rarity === "epic" ? "shiny-card" : "";
  body.innerHTML = `
    <div class="flip-scene">
      <div class="flip-card ${shiny} rarity-${rarity}" id="flipCardInner" onclick="this.classList.toggle('flipped')">
        <div class="flip-face flip-front">
          <img src="${c.card || ""}" alt="${c.name}" onerror="this.style.display='none'">
          <span class="flip-hint">Tap to flip ↻</span>
        </div>
        <div class="flip-face flip-back">
          <h3>${c.emoji || ""} ${c.name}</h3>
          <p class="collect-role">${c.role || ""}</p>
          <p class="flip-story">${c.description || ""}</p>
          <p><strong>Book ${c.book || "?"}</strong> · ${c.isVillain ? "Villain" : "Friend"}</p>
          <span class="rarity-tag">${rarity}</span>
        </div>
      </div>
    </div>
    <div class="flip-actions">
      <button class="btn btn-secondary" onclick="setFavouriteCard('${c.id}');">💖 Favourite</button>
      <button class="btn btn-primary" onclick="closeCardView()">Close</button>
    </div>`;
  modal.classList.remove("hidden");
  sparkleBurst(window.innerWidth / 2, window.innerHeight * 0.4, 12);
}

/* Override viewCard if we patch after load - also assign */
function installAmazingHooks() {
  window.viewCard = viewCardFlip;
}

// Patch celebrate once
(function() {
  const _orig = typeof celebrateBookFinish === "function" ? celebrateBookFinish : null;
  window.celebrateBookFinish = function(book) {
    if (typeof enhancedCelebrate === "function") enhancedCelebrate(book);
    if (_orig) _orig(book);
  };
})();



/* ---- Trio: sticker album + set progress rings ---- */
const BOOK_MOODS = {
  1: "mood-forest",
  2: "mood-island",
  3: "mood-moonlight",
  4: "mood-egypt",
  5: "mood-outback",
  6: "mood-arctic"
};

const STICKER_META = [
  { book: 1, emoji: "🦴", name: "The Lost Bone", place: "Forest & Garden" },
  { book: 2, emoji: "🏝️", name: "Island Treasure", place: "Puppy Island" },
  { book: 3, emoji: "🌙", name: "Moonlight Medal", place: "Hound Manor" },
  { book: 4, emoji: "🗝️", name: "Pharaoh's Key", place: "Egypt" },
  { book: 5, emoji: "💎", name: "Outback Diamond", place: "Australian Outback" },
  { book: 6, emoji: "❄️", name: "Arctic Snowflake", place: "Arctic Magic" }
];

function applyBookMood(bookId) {
  document.body.classList.remove("mood-forest","mood-island","mood-moonlight","mood-egypt","mood-outback","mood-arctic","mood-reading");
  const cls = BOOK_MOODS[bookId];
  if (cls) {
    document.body.classList.add("mood-reading", cls);
  }
}

function clearBookMood() {
  document.body.classList.remove("mood-forest","mood-island","mood-moonlight","mood-egypt","mood-outback","mood-arctic","mood-reading");
}

function renderStickerAlbum() {
  const grid = document.getElementById("stickerAlbumGrid");
  if (!grid) return;
  const earned = new Set([
    ...(state.mapStickers || []),
    ...(state.completedBooks || [])
  ]);
  const badges = state.badges || [];
  grid.innerHTML = STICKER_META.map(s => {
    const has = earned.has(s.book);
    return `<div class="sticker-slot ${has ? "earned" : "locked"}">
      <div class="sticker-emoji">${has ? s.emoji : "⬜"}</div>
      <div class="sticker-name">${s.name}</div>
      <div class="sticker-place">${s.place}</div>
      <div class="sticker-status">${has ? "Collected!" : "Finish the book"}</div>
    </div>`;
  }).join("") + `
    <div class="sticker-slot badge-slot">
      <div class="sticker-emoji">🏅</div>
      <div class="sticker-name">Badges</div>
      <div class="sticker-place">${badges.length} earned</div>
      <button class="btn btn-small" onclick="showSection('badges')">View</button>
    </div>`;
  const countEl = document.getElementById("stickerCount");
  if (countEl) countEl.textContent = `${[...earned].filter(id => id >= 1 && id <= 6).length} / 6`;
}

function renderSetProgressRings() {
  const el = document.getElementById("setProgressRings");
  if (!el || typeof CHARACTERS === "undefined") return;
  if (!state.unlockedCards) state.unlockedCards = [];
  const sets = [
    { id: 1, name: "Forest", emoji: "🌲" },
    { id: 2, name: "Island", emoji: "🏝️" },
    { id: 3, name: "Manor", emoji: "🌙" },
    { id: 4, name: "Egypt", emoji: "🏛️" },
    { id: 5, name: "Outback", emoji: "🏜️" },
    { id: 6, name: "Arctic", emoji: "❄️" }
  ];
  el.innerHTML = sets.map(s => {
    const members = CHARACTERS.filter(c => c.book === s.id);
    const total = members.length || 1;
    const owned = members.filter(c => state.unlockedCards.includes(c.id)).length;
    const pct = Math.round((owned / total) * 100);
    const r = 28;
    const circ = 2 * Math.PI * r;
    const offset = circ - (pct / 100) * circ;
    return `<div class="set-ring-card" title="${owned}/${total}">
      <svg class="set-ring" viewBox="0 0 70 70" width="70" height="70">
        <circle cx="35" cy="35" r="${r}" class="ring-bg"/>
        <circle cx="35" cy="35" r="${r}" class="ring-fg" stroke-dasharray="${circ}" stroke-dashoffset="${offset}"/>
        <text x="35" y="40" text-anchor="middle" class="ring-emoji">${s.emoji}</text>
      </svg>
      <div class="set-ring-label">${s.name}</div>
      <div class="set-ring-count">${owned}/${total}</div>
    </div>`;
  }).join("");
}


/* ---- Splash, Bedtime, Reading streak ---- */
function showSplash() {
  const el = document.getElementById("splashScreen");
  if (!el) return;
  el.classList.remove("hidden");
  el.classList.add("show");
  const done = () => {
    el.classList.add("hide");
    setTimeout(() => {
      el.classList.add("hidden");
      el.classList.remove("show", "hide");
    }, 500);
  };
  setTimeout(done, 1400);
  el.addEventListener("click", done, { once: true });
}

function isBedtime() {
  return document.body.classList.contains("bedtime-mode");
}

function toggleBedtime() {
  const on = document.body.classList.toggle("bedtime-mode");
  if (on) {
    document.body.classList.add("night-mode", "large-text");
    localStorage.setItem("papiNight", "1");
    localStorage.setItem("papiLargeText", "1");
    localStorage.setItem("papiBedtime", "1");
    // hush sparkles: flag
    window._papiHush = true;
    if (typeof showToast === "function") showToast("Bedtime mode on 🌙");
  } else {
    document.body.classList.remove("night-mode", "large-text", "bedtime-mode");
    localStorage.setItem("papiNight", "0");
    localStorage.setItem("papiLargeText", "0");
    localStorage.setItem("papiBedtime", "0");
    window._papiHush = false;
    if (typeof showToast === "function") showToast("Bedtime mode off");
  }
  const btn = document.getElementById("bedtimeBtn");
  if (btn) btn.textContent = on ? "☀️ Day" : "🌙 Bedtime";
  if (typeof sfx === "function" && !on) sfx("click");
}

function applyBedtimePref() {
  if (localStorage.getItem("papiBedtime") === "1") {
    document.body.classList.add("bedtime-mode", "night-mode", "large-text");
    window._papiHush = true;
    const btn = document.getElementById("bedtimeBtn");
    if (btn) btn.textContent = "☀️ Day";
  }
}

function installBedtimeHush() {
  if (window._hushInstalled) return;
  window._hushInstalled = true;
  const sb = window.sparkleBurst;
  const sc = window.sparkleCenter;
  if (typeof sb === "function") {
    window.sparkleBurst = function(x, y, count) {
      if (window._papiHush) return;
      return sb(x, y, count);
    };
  }
  if (typeof sc === "function") {
    window.sparkleCenter = function(count) {
      if (window._papiHush) return;
      return sc(count);
    };
  }
}

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function recordReadingActivity() {
  const today = todayKey();
  const last = localStorage.getItem("papiStreakLast") || "";
  let streak = parseInt(localStorage.getItem("papiStreakCount") || "0", 10);
  if (last === today) {
    // already counted today
  } else {
    const y = new Date();
    y.setDate(y.getDate() - 1);
    const yesterday = y.toISOString().slice(0, 10);
    if (last === yesterday) streak += 1;
    else streak = 1;
    localStorage.setItem("papiStreakLast", today);
    localStorage.setItem("papiStreakCount", String(streak));
    if (streak > 1 && typeof showToast === "function") {
      showToast(`Reading streak: Day ${streak}! 🔥`);
    }
  }
  renderStreakBadge();
  return streak;
}

function getStreak() {
  const last = localStorage.getItem("papiStreakLast") || "";
  const today = todayKey();
  const y = new Date();
  y.setDate(y.getDate() - 1);
  const yesterday = y.toISOString().slice(0, 10);
  let streak = parseInt(localStorage.getItem("papiStreakCount") || "0", 10);
  if (last !== today && last !== yesterday) streak = 0;
  return streak;
}

function renderStreakBadge() {
  const el = document.getElementById("streakBadge");
  if (!el) return;
  const n = getStreak();
  if (n <= 0) {
    el.innerHTML = `<span class="streak-zero">Start a reading streak today!</span>`;
    return;
  }
  el.innerHTML = `<span class="streak-fire">🔥 Day ${n} with Papi</span>`;
}
