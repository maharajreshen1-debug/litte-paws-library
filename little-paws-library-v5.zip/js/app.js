/* ===== Little Paws Library - App Logic ===== */

// ----- State -----
let state = {
  unlockedCharacters: [],       // ALL characters start locked
  ownedColouring: [],
  completedColouring: [],
  ownedOutfits: {},             // { characterId: [outfitId, ...] }
  equippedOutfits: {},          // { characterId: outfitId }
  bookProgress: {},
  completedBooks: [],
  unlockedCards: [],
  setBonusesClaimed: [],
  lifetimeStars: 0,
  badges: [],
  duelWins: 0,
  quizzesPassed: [],
  stars: 0,
  currentBookId: null,
  currentPage: 0,          // 0-based page index for the current book
  currentChapter: 0,       // kept for unlock compatibility
  freeCardClaimed: false,  // has this device claimed its one free card?
  freeCardId: null         // which character was the free card
};

// ----- Load / Save -----
function loadState() {
  const saved = localStorage.getItem("papiLibraryState");
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      state = { ...state, ...parsed };
      if (typeof state.stars !== "number") state.stars = 0;
      if (!Array.isArray(state.unlockedCharacters)) state.unlockedCharacters = [];
      if (!Array.isArray(state.ownedColouring)) state.ownedColouring = [];
      if (!state.ownedOutfits || typeof state.ownedOutfits !== "object") state.ownedOutfits = {};
      if (!state.equippedOutfits || typeof state.equippedOutfits !== "object") state.equippedOutfits = {};
      if (!Array.isArray(state.unlockedCards)) state.unlockedCards = [];
    } catch (e) {
      console.warn("Could not load saved progress");
    }
  }
  // Ensure free-card fields exist
  if (state.freeCardClaimed == null) state.freeCardClaimed = false;
  if (state.freeCardId === undefined) state.freeCardId = null;
  updateStarsDisplay();
  // Show or hide free-card claim banner
  if (typeof updateFreeCardBanner === "function") updateFreeCardBanner();
}

function saveState() {
  localStorage.setItem("papiLibraryState", JSON.stringify(state));
}

function ensureFeatureState() {
  if (state.lifetimeStars == null) state.lifetimeStars = 0;
  if (!state.badges) state.badges = [];
  if (state.duelWins == null) state.duelWins = 0;
  if (!state.quizzesPassed) state.quizzesPassed = [];
  if (!state.unlockedCards) state.unlockedCards = [];
}

// ----- Navigation -----

function renderHomeWidgets() {
  const meet = document.getElementById("meetRow");
  if (meet) {
    const featured = ["papi","rosie","sammy","oliver","toby","felix","benny"];
    meet.innerHTML = featured.map(id => {
      const c = CHARACTERS.find(ch => ch.id === id);
      if (!c) return "";
      const img = c.card
        ? `<img src="${c.card}" alt="${c.name}">`
        : `<div class="meet-emoji">${c.emoji}</div>`;
      return `<div class="meet-chip" onclick="showSection('characters'); setTimeout(()=>showCharacter('${id}'),100)">${img}<span>${c.name}</span></div>`;
    }).join("");
  }
  const hb = document.getElementById("homeBooks");
  if (hb) {
    hb.innerHTML = BOOKS.slice(0,4).map(b =>
      `<img src="images/covers/book${b.id}.jpg" alt="${b.shortTitle}" onclick="openBook(${b.id})" title="${b.shortTitle}">`
    ).join("");
  }
  const hc = document.getElementById("homeColouring");
  if (hc) {
    hc.innerHTML = COLOURING_PAGES.slice(0,4).map(p =>
      p.image ? `<img src="${p.image}" alt="${p.title}" onclick="showSection('colouring')">` : ""
    ).join("");
  }
}

function showSection(sectionId) {
  if (sectionId !== "reader" && typeof clearBookMood === "function") clearBookMood();
  document.querySelectorAll(".section").forEach(s => s.classList.remove("active"));
  document.querySelectorAll(".nav-link").forEach(l => l.classList.remove("active"));

  const section = document.getElementById(sectionId);
  if (section) section.classList.add("active");

  const link = document.querySelector(`.nav-link[data-section="${sectionId}"]`);
  if (link) link.classList.add("active");

  // Highlight bottom nav button
  document.querySelectorAll(".bottom-nav button").forEach(btn => {
    const onclick = btn.getAttribute("onclick") || "";
    btn.classList.toggle("active", onclick.includes(`'${sectionId}'`) || onclick.includes(`"${sectionId}"`));
  });

  // Refresh dynamic content
  if (sectionId === "books" || sectionId === "home") { renderBooks(); if (sectionId === "home") renderHomeWidgets(); }
  if (sectionId === "maps") renderMaps();
  if (sectionId === "cards") renderCardCollection();
  if (sectionId === "home") {
    if (typeof updateFreeCardBanner === "function") updateFreeCardBanner();
    renderHomeBooks();
    updateHomeStars();
    if (typeof renderContinueReading === "function") renderContinueReading();
    if (typeof updateHeroPrimary === "function") updateHeroPrimary();
    if (typeof renderHomeFriendRow === "function") renderHomeFriendRow();
    if (typeof renderHomeColourFan === "function") renderHomeColourFan();
        if (typeof renderWallOfFame === "function") renderWallOfFame();
    if (typeof renderFavouriteCard === "function") renderFavouriteCard();
    if (typeof renderHomeQuizzes === "function") renderHomeQuizzes();
    if (typeof renderPapiTip === "function") renderPapiTip();
    if (typeof renderStreakBadge === "function") renderStreakBadge();
    if (typeof showDailyBannerIfNeeded === "function") showDailyBannerIfNeeded();
  }
  if (sectionId === "cards") {
    renderCardCollection();
    if (typeof renderMyAlbum === "function") renderMyAlbum();
  if (typeof renderSetProgressRings === "function") renderSetProgressRings();
    if (typeof renderSetProgressRings === "function") renderSetProgressRings();
  }
  if (sectionId === "stickers") {
    if (typeof renderStickerAlbum === "function") renderStickerAlbum();
  }
  if (sectionId === "badges") { if (typeof renderBadges === "function") renderBadges(); }
  if (sectionId === "parent") { if (typeof renderParent === "function") renderParent(); }
  if (typeof sfx === "function") sfx("click");
  if (sectionId === "characters") renderCharacters();
  if (sectionId === "colouring") renderColouring();
  if (sectionId === "progress") renderProgress();
  if (sectionId === "tcg") {
    if (typeof tcgInit === "function") tcgInit();
  }
}

// Mobile menu
document.getElementById("menuToggle")?.addEventListener("click", () => {
  document.querySelector(".nav-links")?.classList.toggle("open");
});

document.querySelectorAll(".nav-link").forEach(link => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    const section = link.dataset.section;
    showSection(section);
    document.querySelector(".nav-links")?.classList.remove("open");
  });
});

// ----- Books -----
function renderBooks() {
  const homeGrid = document.getElementById("homeBookGrid");
  const booksGrid = document.getElementById("booksGrid");

  const html = BOOKS.map(book => {
    const progress = state.bookProgress[book.id] ?? -1;
    const isCompleted = state.completedBooks.includes(book.id);
    let statusClass = "not-started";
    let statusText = "Not started";
    if (isCompleted) {
      statusClass = "completed";
      statusText = "Completed ✓";
    } else if (progress >= 0) {
      statusClass = "in-progress";
      statusText = `Chapter ${progress + 1}`;
    }

    return `
      <div class="book-card" onclick="openBook(${book.id})">
        <div class="book-cover">
          <img src="images/covers/book${book.id}.jpg" alt="${book.title}" class="cover-img" loading="lazy">
        </div>
        <div class="book-info">
          <h3>${book.title}</h3>
          <p>${book.description}</p>
          <span class="book-status ${statusClass}">${statusText}</span>
        </div>
      </div>
    `;
  }).join("");

  const homeHtml = BOOKS.map(book => {
    const isCompleted = state.completedBooks.includes(book.id);
    return `
      <button class="home-cover-card" onclick="openBook(${book.id})" title="${book.shortTitle || book.title}">
        <img src="images/covers/book${book.id}.jpg" alt="${book.shortTitle || book.title}" loading="lazy">
        <span class="home-cover-title">${book.shortTitle || book.title}</span>
        ${isCompleted ? '<span class="home-cover-done">✓</span>' : ''}
      </button>`;
  }).join("");

  if (homeGrid) homeGrid.innerHTML = homeHtml;
  if (booksGrid) booksGrid.innerHTML = html;
}

// Page counts for each book (matches the image files)
const BOOK_PAGE_COUNTS = { 1: 7, 2: 8, 3: 9, 4: 12, 5: 14, 6: 16 };

// Which page numbers (1-based) unlock which characters (approximate chapter boundaries)
const PAGE_UNLOCKS = {
  1: { 2: ["papi","bella"], 4: ["ollie","felix"], 7: ["toby"] },
  2: { 2: ["oliver","sammy"], 5: ["bruno","manny"], 8: ["tyson"] },
  3: { 3: ["rosie","jackie"], 6: ["billy","willy","sandy"], 9: ["mike"] },
  4: { 4: ["cammy"], 8: ["croco"], 12: ["brutus"] },
  5: { 5: ["cooper","kim"], 10: ["peter","brian"], 14: ["dan","andy"] },
  6: { 5: ["owen","benny"], 11: ["fred","peggy","winston","harry"], 16: ["wendy","poppy"] }
};

function getBookPages(bookId) {
  const count = BOOK_PAGE_COUNTS[bookId] || 0;
  return Array.from({length: count}, (_, i) => i + 1); // 1-based page numbers
}

function openBook(bookId) {
  const book = BOOKS.find(b => b.id === bookId);
  if (!book) return;

  state.currentBookId = bookId;
  // Restore last page the child was on (or start at 0)
  const saved = state.bookProgress[bookId];
  state.currentPage = (typeof saved === "number" && saved >= 0) ? saved : 0;
  const pages = getBookPages(bookId);
  if (state.currentPage >= pages.length) state.currentPage = Math.max(0, pages.length - 1);

  document.getElementById("readerTitle").textContent = book.title;
  if (typeof applyBookMood === "function") applyBookMood(book.id);
  if (typeof recordReadingActivity === "function") recordReadingActivity();
  renderPage();
  showSection("reader");
}

function renderPage() {
  const book = BOOKS.find(b => b.id === state.currentBookId);
  if (!book) return;

  const pages = getBookPages(book.id);
  const total = pages.length;
  const pageNum = pages[state.currentPage]; // 1-based
  const numStr = String(pageNum).padStart(2, "0");

  document.getElementById("chapterCounter").textContent = `Page ${state.currentPage + 1} of ${total}`;
  document.getElementById("chapterProgress").style.width = `${((state.currentPage + 1) / total) * 100}%`;

  let html = `<div class="reader-pages single-page">
    <img src="images/pages/book${book.id}/page${numStr}.jpg"
         alt="Page ${pageNum}"
         class="reader-page-img reader-page-large"
         loading="eager"
         onerror="this.alt='Page image not found'; this.style.opacity=0.3;">
  </div>`;

  // Show moral only on the very last page
  if (state.currentPage === total - 1) {
    html += `<div class="moral"><strong>Moral of the Story:</strong> ${book.moral}</div>`;
  }

  document.getElementById("readerContent").innerHTML = html;

  document.getElementById("prevChapter").disabled = state.currentPage === 0;
  document.getElementById("nextChapter").textContent =
    state.currentPage === total - 1 ? "Finish Book ✓" : "Next Page →";
}

function changeChapter(dir) {  // kept name so HTML buttons still work
  const book = BOOKS.find(b => b.id === state.currentBookId);
  if (!book) return;

  const pages = getBookPages(book.id);
  const total = pages.length;
  const newIndex = state.currentPage + dir;

  // Finish book
  if (dir === 1 && state.currentPage === total - 1) {
    awardStars(150, "Finished the whole book!");
    // Final unlocks for last page
    applyPageUnlocks(book.id, pages[state.currentPage]);
    finishBook(book);
    return;
  }

  if (newIndex < 0 || newIndex >= total) return;

  // Moving forward to a new page
  if (dir === 1) {
    const prevProgress = state.bookProgress[book.id] ?? -1;
    if (newIndex > prevProgress) {
      // Small star reward every few pages
      if ((newIndex + 1) % 3 === 0) {
        awardStars(40, "Great reading!");
      }
      applyPageUnlocks(book.id, pages[newIndex]);
    }
  }

  state.currentPage = newIndex;
  state.bookProgress[book.id] = Math.max(state.bookProgress[book.id] ?? -1, newIndex);
  // Keep a rough chapter index for any old code
  state.currentChapter = Math.floor((newIndex / total) * book.chapters.length);
  saveState();
  renderPage();
}

function applyPageUnlocks(bookId, pageNum) {
  const unlocks = (PAGE_UNLOCKS[bookId] || {})[pageNum];
  if (!unlocks) return;
  unlocks.forEach(id => {
    if (!state.unlockedCharacters.includes(id)) {
      state.unlockedCharacters.push(id);
      // Also give the card for free when unlocked by reading
      if (!state.unlockedCards.includes(id)) {
        state.unlockedCards.push(id);
      }
      const c = CHARACTERS.find(ch => ch.id === id);
      if (c) showUnlockToast(`🔓 You met ${c.name}!`);
    }
  });
  saveState();
}

function finishBook(book) {
  if (!state.completedBooks.includes(book.id)) {
    state.completedBooks.push(book.id);
    if (typeof checkBadges === "function") checkBadges();
  if (typeof renderHomeBooks === "function") renderHomeBooks();
  if (typeof updateHomeStars === "function") updateHomeStars();
  }
  state.bookProgress[book.id] = book.chapters.length - 1;
  saveState();
  showUnlockToast(`🎉 You finished "${book.shortTitle}"! Keep earning ⭐ to unlock friends!`);
  if (typeof renderContinueReading === "function") renderContinueReading();
    if (typeof updateHeroPrimary === "function") updateHeroPrimary();
    if (typeof renderHomeFriendRow === "function") renderHomeFriendRow();
    if (typeof renderHomeColourFan === "function") renderHomeColourFan();
      if (typeof renderWallOfFame === "function") renderWallOfFame();
    if (typeof renderFavouriteCard === "function") renderFavouriteCard();
    if (typeof renderHomeQuizzes === "function") renderHomeQuizzes();
    if (typeof renderPapiTip === "function") renderPapiTip();
    if (typeof renderStreakBadge === "function") renderStreakBadge();
  if (typeof celebrateBookFinish === "function") celebrateBookFinish(book);
  else setTimeout(() => showSection("progress"), 1500);
}

// ----- Stars -----
function awardStars(amount, reason) {
  if (typeof recordReadingActivity === "function" && reason && /chapter|book|read/i.test(reason)) {
    recordReadingActivity();
  }
  state.stars += amount;
  saveState();
  updateStarsDisplay();
  showUnlockToast(`⭐ +${amount} stars! ${reason || ""}`);
}

function updateStarsDisplay() {
  document.querySelectorAll(".stars-count").forEach(el => {
    el.textContent = state.stars;
  });
}

function isAreaUnlocked(bookId) {
  return state.completedBooks.includes(bookId);
}

function buyCharacter(id) {
  const c = CHARACTERS.find(ch => ch.id === id);
  if (!c) return;
  if (state.unlockedCharacters.includes(id)) {
    showUnlockToast("Already unlocked!");
    return;
  }
  if (!isAreaUnlocked(c.book)) {
    showUnlockToast(`Complete Book ${c.book} first to unlock this area!`);
    return;
  }
  if (state.stars < c.cost) {
    showUnlockToast(`Not enough stars! Need ${c.cost} ⭐`);
    return;
  }
  state.stars -= c.cost;
  state.unlockedCharacters.push(id);
  if (!state.ownedOutfits[id]) state.ownedOutfits[id] = [];
  saveState();
  updateStarsDisplay();
  showUnlockToast(`🔓 Unlocked ${c.name}!`);
  renderCharacters();
  showCharacter(id);
}

function buyOutfit(charId, outfitId) {
  if (!state.unlockedCharacters.includes(charId)) {
    showUnlockToast("Unlock the character first!");
    return;
  }
  const outfit = OUTFITS.find(o => o.id === outfitId);
  if (!outfit) return;
  if (!state.ownedOutfits[charId]) state.ownedOutfits[charId] = [];
  if (state.ownedOutfits[charId].includes(outfitId)) {
    // Equip it
    state.equippedOutfits[charId] = outfitId;
    saveState();
    showUnlockToast(`Equipped ${outfit.emoji} ${outfit.name}!`);
    showCharacter(charId);
    return;
  }
  if (state.stars < outfit.cost) {
    showUnlockToast(`Not enough stars! Need ${outfit.cost} ⭐`);
    return;
  }
  state.stars -= outfit.cost;
  state.ownedOutfits[charId].push(outfitId);
  state.equippedOutfits[charId] = outfitId;
  saveState();
  updateStarsDisplay();
  showUnlockToast(`🛍️ Bought ${outfit.emoji} ${outfit.name}!`);
  showCharacter(charId);
}

function buyColouring(id) {
  const page = COLOURING_PAGES.find(p => p.id === id);
  if (!page) return;
  if (state.ownedColouring.includes(id)) {
    openColouring(id);
    return;
  }
  if (state.stars < page.cost) {
    showUnlockToast(`Not enough stars! Need ${page.cost} ⭐`);
    return;
  }
  state.stars -= page.cost;
  state.ownedColouring.push(id);
  saveState();
  updateStarsDisplay();
  showUnlockToast(`🎨 Colouring page unlocked!`);
  renderColouring();
  openColouring(id);
}

function showUnlockToast(message) {
  const toast = document.getElementById("unlockToast");
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 3500);
}

function renderCharacters(filter = "all") {
  const grid = document.getElementById("characterGrid");
  let list = CHARACTERS;

  if (filter === "unlocked") {
    list = CHARACTERS.filter(c => state.unlockedCharacters.includes(c.id));
  } else if (filter === "locked") {
    list = CHARACTERS.filter(c => !state.unlockedCharacters.includes(c.id));
  }

  if (!list.length) {
    grid.innerHTML = `<div class="empty-state">
      <p>No friends match this filter.</p>
      <p>Read chapters to earn ⭐, then unlock friends here!</p>
      <button class="btn btn-primary" onclick="showSection('books')">📚 Read a book</button>
    </div>`;
    return;
  }
  grid.innerHTML = list.map(c => {
    const isUnlocked = state.unlockedCharacters.includes(c.id);
    // Always show the real character image
    const avatarContent = c.card
      ? `<img src="${c.card}" alt="${c.name}" class="avatar-img" loading="lazy" decoding="async">`
      : `<span class="avatar-emoji">${c.emoji}</span>`;
    const areaOpen = isAreaUnlocked(c.book);
    const priceLabel = `⭐ ${c.cost}`;
    const statusLabel = isUnlocked
      ? "Unlocked ✓"
      : (!areaOpen ? `Finish Book ${c.book}` : "Locked");
    const villainTag = c.isVillain ? " 😈" : "";
    return `
      <div class="character-card ${isUnlocked ? "unlocked" : "locked"}" onclick="showCharacter('${c.id}')">
        <div class="character-avatar">${avatarContent}</div>
        <h4>${c.name}${villainTag}</h4>
        <div class="char-price">${priceLabel}</div>
        <div class="char-lock-row">
          ${isUnlocked
            ? '<span class="lock-open">🔓 Unlocked</span>'
            : '<span class="lock-closed">🔒</span>'}
        </div>
        ${!isUnlocked ? `<div class="book-tag">${statusLabel}</div>` : ""}
      </div>
    `;
  }).join("");
}

// Filter buttons
document.querySelectorAll(".filter-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".filter-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    renderCharacters(btn.dataset.filter);
  });
});

function showCharacter(id) {
  const c = CHARACTERS.find(ch => ch.id === id);
  if (!c) return;

  const isUnlocked = state.unlockedCharacters.includes(id);
  const areaOpen = isAreaUnlocked(c.book);
  const modal = document.getElementById("characterModal");
  const body = document.getElementById("modalBody");
  const equipped = state.equippedOutfits[id];
  const equippedOutfit = OUTFITS.find(o => o.id === equipped);

  if (!isUnlocked) {
    let extra = "";
    if (!areaOpen) {
      extra = `<p style="color:#e17055;font-weight:700;">🔒 Complete Book ${c.book} to unlock this area first!</p>`;
    }
    const typeLabel = c.isVillain ? "Villain" : "Friend";
    body.innerHTML = `
      <div class="modal-avatar locked-avatar" style="display:flex;align-items:center;justify-content:center;font-size:4rem;background:#f0f0f0;border-radius:50%;width:120px;height:120px;">🔒</div>
      <h3>${c.name} ${c.isVillain ? "😈" : ""}</h3>
      <p class="role">${c.role} · ${typeLabel}</p>
      <p>Locked. Earn ⭐ by reading chapters, finish the book's area, then unlock!</p>
      ${extra}
      <p style="margin:1rem 0;font-size:1.3rem;font-weight:800;">⭐ ${c.cost} stars</p>
      <p style="font-size:0.9rem;color:#636e72;">You have <strong>${state.stars}</strong> stars</p>
      <button class="btn btn-primary" style="margin-top:1rem;" onclick="buyCharacter('${c.id}')">
        Unlock for ⭐ ${c.cost}
      </button>
    `;
  } else {
    let avatar;
    if (c.card) {
      avatar = `<img src="${c.card}" alt="${c.name}" class="avatar-img card-full">`;
    } else {
      avatar = `<span class="avatar-emoji">${c.emoji}</span>`;
    }
    const owned = state.ownedOutfits[id] || [];
    const outfitHtml = OUTFITS.map(o => {
      const has = owned.includes(o.id);
      const eq = equipped === o.id;
      const label = eq ? "Equipped" : (has ? "Equip" : `⭐ ${o.cost}`);
      return `<button class="outfit-btn ${eq ? "equipped" : ""}" onclick="buyOutfit('${id}','${o.id}')">${o.emoji} ${o.name}<br><small>${label}</small></button>`;
    }).join("");

    const villainNote = c.isVillain
      ? `<p class="backstory-villain">😈 Villain · Unlock cost <strong>300 ⭐</strong></p>`
      : "";
    body.innerHTML = `
      <div class="modal-avatar">${avatar}</div>
      <h3>${c.name} ${equippedOutfit ? equippedOutfit.emoji : ""}</h3>
      <p class="role">${c.role}</p>
      ${villainNote}
      <div class="backstory-box">
        <h4>📖 Backstory</h4>
        <p>${c.description}</p>
        <p class="backstory-meta">First appears in <strong>Book ${c.book}</strong> · ${
          c.book === 1 ? "Garden & Forest" :
          c.book === 2 ? "Puppy Island" :
          c.book === 3 ? "Moonlight Village" :
          c.book === 4 ? "Egyptian Desert" :
          c.book === 5 ? "Australian Outback" : "Arctic Lands"
        }</p>
      </div>
      <h4 style="margin-top:1.2rem;">🛍️ Outfits</h4>
      <div class="outfit-grid">${outfitHtml}</div>
    `;
  }
  modal.classList.add("open");
}

function closeModal() {
  document.getElementById("characterModal").classList.remove("open");
}

document.getElementById("characterModal")?.addEventListener("click", (e) => {
  if (e.target.id === "characterModal") closeModal();
});

// ----- Colouring -----
let currentColour = "#FF6B35";
let brushSize = 10;
let isDrawing = false;
let currentTool = "brush";
let currentColouringId = null;
let colourHistory = [];          // undo stack
const MAX_HISTORY = 25;

const COLOURS = [
  "#FF6B35", "#FFE66D", "#4ECDC4", "#7B68EE", "#FF6B9D",
  "#00B894", "#0984e3", "#2D3436", "#FFFFFF", "#FD79A8",
  "#FDCB6E", "#E17055", "#6C5CE7", "#00CEC9", "#B2BEC3",
  "#FF9F43", "#10AC84", "#5F27CD", "#EE5A24", "#C8D6E5"
];

function renderColouring() {
  const grid = document.getElementById("colouringGrid");
  grid.innerHTML = COLOURING_PAGES.map(p => {
    const owned = state.ownedColouring.includes(p.id);
    const done = state.completedColouring.includes(p.id);
    const status = done ? "Done ✓" : (owned ? "Ready to colour" : `⭐ ${p.cost}`);
    const preview = p.image
      ? `<div class="colouring-preview-wrap"><img src="${p.image}" alt="${p.title}" class="colouring-preview-img" loading="lazy"></div>`
      : `<div class="colouring-preview">${p.emoji}</div>`;
    return `
      <div class="colouring-card ${done ? "done" : ""} ${owned ? "" : "locked-colouring"}" onclick="buyColouring('${p.id}')">
        ${preview}
        <h4>${p.title}</h4>
        <div class="book-tag">${status}</div>
      </div>
    `;
  }).join("");
}

function pushHistory() {
  const canvas = document.getElementById("colourCanvas");
  if (!canvas) return;
  try {
    colourHistory.push(canvas.toDataURL("image/png"));
    if (colourHistory.length > MAX_HISTORY) colourHistory.shift();
  } catch (e) {}
}

function openColouring(id) {
  if (!state.ownedColouring.includes(id)) {
    buyColouring(id);
    return;
  }
  currentColouringId = id;
  colourHistory = [];
  const page = COLOURING_PAGES.find(p => p.id === id);
  document.getElementById("colouringTitle").textContent = page.title;
  document.getElementById("colouringWorkspace").classList.remove("hidden");
  document.getElementById("colouringGrid").style.display = "none";

  const palette = document.getElementById("colourPalette");
  palette.innerHTML = COLOURS.map(c =>
    `<div class="colour-swatch ${c === currentColour ? "active" : ""}" style="background:${c}" onclick="selectColour('${c}')"></div>`
  ).join("");

  setTool("brush");

  const canvas = document.getElementById("colourCanvas");
  const ctx = canvas.getContext("2d");

  if (page.image) {
    const img = new Image();
    img.onload = () => {
      const maxW = 900;
      const maxH = 1100;
      let w = img.width;
      let h = img.height;
      const scale = Math.min(maxW / w, maxH / h, 1);
      w = Math.round(w * scale);
      h = Math.round(h * scale);
      canvas.width = w;
      canvas.height = h;
      ctx.fillStyle = "#FFFFFF";
      ctx.fillRect(0, 0, w, h);
      ctx.drawImage(img, 0, 0, w, h);
      pushHistory();
      setupCanvasEvents();
    };
    img.onerror = () => {
      canvas.width = 800;
      canvas.height = 600;
      ctx.fillStyle = "#FFFFFF";
      ctx.fillRect(0, 0, 800, 600);
      pushHistory();
      setupCanvasEvents();
    };
    img.src = page.image;
  } else {
    canvas.width = 800;
    canvas.height = 600;
    ctx.fillStyle = "#FFFFFF";
    ctx.fillRect(0, 0, 800, 600);
    pushHistory();
    setupCanvasEvents();
  }
}

function closeColouring() {
  document.getElementById("colouringWorkspace").classList.add("hidden");
  document.getElementById("colouringGrid").style.display = "grid";
  currentColouringId = null;
  colourHistory = [];
}

function selectColour(c) {
  currentColour = c;
  if (currentTool === "eraser") currentTool = "brush";
  document.querySelectorAll(".colour-swatch").forEach(s => {
    s.classList.toggle("active", s.style.background === c || s.style.backgroundColor === c);
  });
  updateToolButtons();
}

function setTool(tool) {
  currentTool = tool;
  updateToolButtons();
}

function updateToolButtons() {
  ["brush","fill","eraser"].forEach(t => {
    const btn = document.getElementById("tool" + t.charAt(0).toUpperCase() + t.slice(1));
    if (btn) btn.classList.toggle("active", currentTool === t);
  });
}

function undoColouring() {
  if (colourHistory.length < 2) return;
  colourHistory.pop(); // remove current
  const prev = colourHistory[colourHistory.length - 1];
  const canvas = document.getElementById("colourCanvas");
  const ctx = canvas.getContext("2d");
  const img = new Image();
  img.onload = () => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0);
  };
  img.src = prev;
}

function clearCanvas() {
  const canvas = document.getElementById("colourCanvas");
  const ctx = canvas.getContext("2d");
  pushHistory();
  ctx.fillStyle = "#FFFFFF";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  // Redraw the original line art if possible
  const page = COLOURING_PAGES.find(p => p.id === currentColouringId);
  if (page && page.image) {
    const img = new Image();
    img.onload = () => {
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      pushHistory();
    };
    img.src = page.image;
  }
}

function saveColouring() {
  const canvas = document.getElementById("colourCanvas");
  if (!canvas) return;
  const link = document.createElement("a");
  const page = COLOURING_PAGES.find(p => p.id === currentColouringId);
  const name = page ? page.title.replace(/\s+/g, "-").toLowerCase() : "colouring";
  link.download = name + ".png";
  link.href = canvas.toDataURL("image/png");
  link.click();
  showUnlockToast("💾 Saved! Check your downloads");
}

function printColouring() {
  const canvas = document.getElementById("colourCanvas");
  if (!canvas) return;
  const dataUrl = canvas.toDataURL("image/png");
  const win = window.open("", "_blank");
  if (!win) {
    showUnlockToast("Please allow pop-ups to print");
    return;
  }
  const page = COLOURING_PAGES.find(p => p.id === currentColouringId);
  const title = page ? page.title : "Colouring Page";
  win.document.write(`
    <html><head><title>${title}</title>
    <style>body{margin:0;display:flex;justify-content:center;align-items:center;min-height:100vh;}
    img{max-width:100%;max-height:100vh;}</style></head>
    <body><img src="${dataUrl}" onload="window.print();setTimeout(()=>window.close(),500)"></body></html>
  `);
  win.document.close();
}

// Simple flood-fill for the Fill tool
function floodFill(ctx, startX, startY, fillColor) {
  const canvas = ctx.canvas;
  const w = canvas.width;
  const h = canvas.height;
  const imageData = ctx.getImageData(0, 0, w, h);
  const data = imageData.data;
  const sx = Math.floor(startX);
  const sy = Math.floor(startY);
  if (sx < 0 || sy < 0 || sx >= w || sy >= h) return;

  const startPos = (sy * w + sx) * 4;
  const startR = data[startPos];
  const startG = data[startPos + 1];
  const startB = data[startPos + 2];
  const startA = data[startPos + 3];

  // Parse fill colour
  const tmp = document.createElement("div");
  tmp.style.color = fillColor;
  document.body.appendChild(tmp);
  const computed = getComputedStyle(tmp).color;
  document.body.removeChild(tmp);
  const match = computed.match(/\d+/g);
  if (!match) return;
  const fillR = parseInt(match[0]);
  const fillG = parseInt(match[1]);
  const fillB = parseInt(match[2]);
  const fillA = 255;

  // Don't fill if already same colour
  if (startR === fillR && startG === fillG && startB === fillB) return;

  const tolerance = 40;
  function matchStart(pos) {
    return Math.abs(data[pos] - startR) <= tolerance &&
           Math.abs(data[pos+1] - startG) <= tolerance &&
           Math.abs(data[pos+2] - startB) <= tolerance &&
           Math.abs(data[pos+3] - startA) <= tolerance;
  }

  const stack = [[sx, sy]];
  const visited = new Uint8Array(w * h);

  while (stack.length) {
    const [x, y] = stack.pop();
    if (x < 0 || y < 0 || x >= w || y >= h) continue;
    const idx = y * w + x;
    if (visited[idx]) continue;
    visited[idx] = 1;
    const pos = idx * 4;
    if (!matchStart(pos)) continue;
    data[pos] = fillR;
    data[pos+1] = fillG;
    data[pos+2] = fillB;
    data[pos+3] = fillA;
    stack.push([x+1, y], [x-1, y], [x, y+1], [x, y-1]);
  }
  ctx.putImageData(imageData, 0, 0);
}

function setupCanvasEvents() {
  const canvas = document.getElementById("colourCanvas");
  const ctx = canvas.getContext("2d");

  function getPos(e) {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  }

  function start(e) {
    const pos = getPos(e);
    if (currentTool === "fill") {
      pushHistory();
      floodFill(ctx, pos.x, pos.y, currentColour);
      e.preventDefault();
      return;
    }
    isDrawing = true;
    pushHistory();
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
    e.preventDefault();
  }

  function draw(e) {
    if (!isDrawing || currentTool === "fill") return;
    const pos = getPos(e);
    ctx.lineWidth = brushSize;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    if (currentTool === "eraser") {
      ctx.strokeStyle = "#FFFFFF";
      ctx.lineWidth = brushSize * 2.5;
    } else {
      ctx.strokeStyle = currentColour;
    }
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
    e.preventDefault();
  }

  function stop() {
    isDrawing = false;
    ctx.beginPath();
  }

  canvas.onmousedown = start;
  canvas.onmousemove = draw;
  canvas.onmouseup = stop;
  canvas.onmouseleave = stop;
  canvas.ontouchstart = start;
  canvas.ontouchmove = draw;
  canvas.ontouchend = stop;

  const sizeInput = document.getElementById("brushSize");
  if (sizeInput) {
    sizeInput.oninput = (e) => {
      brushSize = parseInt(e.target.value);
    };
  }
}

function completeColouring() {
  if (!currentColouringId) return;
  if (!state.completedColouring.includes(currentColouringId)) {
    state.completedColouring.push(currentColouringId);
    state.stars += 25; state.lifetimeStars = (state.lifetimeStars||0)+25; if (typeof sfx==='function') sfx('star');
    saveState();
    updateStarsDisplay();
    showUnlockToast("🎨 Colouring complete! +25 ⭐");
  }
  closeColouring();
  renderColouring();
}

// ----- Progress -----
function renderProgress() {
  updateStarsDisplay();
  document.getElementById("booksReadCount").textContent =
    state.completedBooks.length || Object.keys(state.bookProgress).length;
  document.getElementById("charactersUnlockedCount").textContent = state.unlockedCharacters.length;
  document.getElementById("colouringDoneCount").textContent = state.completedColouring.length;

  const bookList = document.getElementById("bookProgressList");
  bookList.innerHTML = BOOKS.map(b => {
    const done = state.completedBooks.includes(b.id);
    const quizBtn = done ? `<button class="btn btn-small" onclick="openQuiz(${b.id})">🧠 Quiz</button>` : "";
    const progress = state.bookProgress[b.id];
    let status = "Not started";
    if (done) status = "✅ Completed";
    else if (progress >= 0) status = `📖 Chapter ${progress + 1} of ${b.chapters.length}`;
    return `<div style="padding:0.6rem 0;border-bottom:1px solid #eee;display:flex;justify-content:space-between;align-items:center;gap:0.5rem;flex-wrap:wrap;">
      <span>${b.emoji} ${b.shortTitle}</span>
      <span style="color:#636e72;font-size:0.9rem;">${status} ${quizBtn}</span>
    </div>`;
  }).join("");

  const unlockedList = document.getElementById("unlockedList");
  if (state.unlockedCharacters.length === 0) {
    unlockedList.innerHTML = `<p style="color:#636e72;">No friends unlocked yet. Read chapters to earn ⭐ and unlock them!</p>`;
  } else {
    unlockedList.innerHTML = state.unlockedCharacters.map(id => {
      const c = CHARACTERS.find(ch => ch.id === id);
      if (!c) return "";
      return `<div class="mini-char">${c.emoji} ${c.name}</div>`;
    }).join("");
  }
}

function resetProgress() {
  if (confirm("Are you sure you want to reset all progress? This cannot be undone.")) {
    state = {
      unlockedCharacters: [],
      ownedColouring: [],
      completedColouring: [],
      ownedOutfits: {},
      equippedOutfits: {},
      bookProgress: {},
      completedBooks: [],
      unlockedCards: [],
      setBonusesClaimed: [],
      lifetimeStars: 0,
      badges: [],
      duelWins: 0,
      quizzesPassed: [],
      stars: 0,
      currentBookId: null,
      currentPage: 0,
      currentChapter: 0,
      freeCardClaimed: false,
      freeCardId: null
    };
    saveState();
    updateStarsDisplay();
    if (typeof updateFreeCardBanner === "function") updateFreeCardBanner();
    renderProgress();
    showUnlockToast("Progress has been reset");
  }
}

// ----- Story Maps -----
let currentMapBook = 1;



// ----- Card Collection (no duel) -----
let cardFilter = "all";

function filterCards(f) {
  cardFilter = f;
  document.querySelectorAll(".cards-filter .btn-small").forEach(b => b.classList.remove("active"));
  try { if (typeof event !== "undefined" && event.target) event.target.classList.add("active"); } catch(e) {}
  renderCardCollection();
  if (typeof renderMyAlbum === 'function') renderMyAlbum();
  if (typeof renderSetProgressRings === 'function') renderSetProgressRings();
  if (typeof renderWallOfFame === 'function') renderWallOfFame();
}

function renderCardCollection() {
  const grid = document.getElementById("cardCollectionGrid");
  if (!grid || typeof CHARACTERS === "undefined") return;
  if (!state.unlockedCards) state.unlockedCards = [];

  let list = CHARACTERS.filter(c => {
    const owned = state.unlockedCards.includes(c.id);
    if (cardFilter === "friends") return !c.isVillain;
    if (cardFilter === "villains") return !!c.isVillain;
    if (cardFilter === "locked") return !owned;
    if (cardFilter === "owned") return owned;
    return true;
  });
  const sq = (window._cardSearchQ || "").toLowerCase();
  if (sq) {
    list = list.filter(c =>
      (c.name || "").toLowerCase().includes(sq) ||
      (c.role || "").toLowerCase().includes(sq) ||
      (c.description || "").toLowerCase().includes(sq)
    );
  }

  const ownedCount = state.unlockedCards.filter(id => CHARACTERS.some(c => c.id === id)).length;
  const tot = document.getElementById("cardsTotalCount");
  const own = document.getElementById("cardsOwnedCount");
  if (tot) tot.textContent = CHARACTERS.length;
  if (own) own.textContent = ownedCount;

  if (!list.length) {
    grid.innerHTML = `<div class="empty-state">
      <p>No cards match.</p>
      <p>Read chapters to earn ⭐, then unlock friends here!</p>
      <button class="btn btn-primary" onclick="showSection('books')">📚 Read a book</button>
    </div>`;
    return;
  }
  grid.innerHTML = list.map(c => {
    const owned = state.unlockedCards.includes(c.id);
    const cost = c.cost || 50;
    const img = c.card || "";
    const rarity = (typeof cardRarity === "function") ? cardRarity(c) : "common";
    return `
      <div class="collect-card rarity-${rarity} ${owned ? "owned" : "locked"} ${c.isVillain ? "villain" : ""}">
        <div class="collect-card-art">
          ${img ? `<img src="${img}" alt="${c.name}" loading="lazy" decoding="async" onerror="this.style.display='none'">` : `<div class="collect-emoji">${c.emoji||"🐾"}</div>`}
          ${owned ? "" : `<div class="collect-lock">🔒</div>`}
        </div>
        <div class="collect-card-body">
          <h3>${c.name}</h3>
          <p class="collect-role">${c.role || ""}</p>
          <p class="collect-cost">${owned ? "✅ In your album" : `⭐ ${cost} to unlock`}</p>
          <span class="rarity-tag">${rarity}</span>
          ${owned
            ? `<button class="btn btn-small" onclick="viewCard('${c.id}')">View card</button>`
            : `<button class="btn btn-primary btn-small" onclick="unlockCard('${c.id}')">Unlock</button>`}
        </div>
      </div>`;
  }).join("");
}

function unlockCard(id) {
  const c = CHARACTERS.find(x => x.id === id);
  if (!c) return;
  if (!state.unlockedCards) state.unlockedCards = [];
  if (state.unlockedCards.includes(id)) return;
  const cost = c.cost || 50;
  if ((state.stars || 0) < cost) {
    if (typeof showToast === "function") showToast(`Need ${cost} ⭐ to unlock ${c.name}'s card`);
    else alert(`Need ${cost} stars`);
    return;
  }
  state.stars -= cost;
  state.unlockedCards.push(id);
  if (typeof checkSetCompletion === 'function') checkSetCompletion(id);
  if (state.unlockedCharacters && !state.unlockedCharacters.includes(id)) state.unlockedCharacters.push(id);
  saveState();
  if (typeof updateStarsDisplay === "function") updateStarsDisplay();
  if (typeof sfx === "function") sfx("unlock");
  if (typeof showToast === "function") showToast(`🃏 ${c.name} card unlocked!`);
  if (typeof sparkleCenter === "function") sparkleCenter(20);
  if (typeof checkBadges === "function") checkBadges();
  if (typeof renderHomeBooks === "function") renderHomeBooks();
  if (typeof updateHomeStars === "function") updateHomeStars();
  renderCardCollection();
  if (typeof renderMyAlbum === 'function') renderMyAlbum();
  if (typeof renderSetProgressRings === 'function') renderSetProgressRings();
  if (typeof renderWallOfFame === 'function') renderWallOfFame();
}

function viewCard(id) {
  const c = CHARACTERS.find(x => x.id === id);
  if (!c) return;
  const modal = document.getElementById("cardViewModal");
  const body = document.getElementById("cardViewBody");
  if (!modal || !body) {
    alert(c.name + " — " + (c.description || c.role || ""));
    return;
  }
  const traits = (c.traits && c.traits.length)
    ? c.traits.map(t => `<span class="trait-chip">${t}</span>`).join(" ")
    : "";
  const isOwned = (state.unlockedCards || []).includes(c.id);
  const isFreeCard = state.freeCardId === c.id;
  body.innerHTML = `
    <div class="full-card-wrap">
      <img class="card-view-img full-card-img" src="${c.card||""}" alt="${c.name}" onerror="this.style.display='none'">
      <div class="full-card-info">
        <h2>${c.emoji||""} ${c.name}</h2>
        <p class="collect-role">${c.role||""}</p>
        <p class="card-type">${c.isVillain ? "🦹 Villain" : "💛 Friend"} · Book ${c.book||"?"}</p>
        ${traits ? `<div class="traits-row"><strong>Traits:</strong> ${traits}</div>` : ""}
        <p class="card-desc">${c.description||""}</p>
        ${isFreeCard ? '<p class="free-badge">🎁 Your free starter card</p>' : ""}
        ${isOwned ? '<p class="owned-badge">✅ In your collection</p>' : '<p class="locked-badge">🔒 Not yet unlocked</p>'}
        <div class="card-actions">
          <button class="btn btn-secondary" onclick="setFavouriteCard('${c.id}'); closeCardView();">💖 Set as favourite</button>
          <button class="btn btn-primary" onclick="closeCardView()">Close</button>
        </div>
      </div>
    </div>`;
  modal.classList.remove("hidden");
}

function closeCardView() {
  document.getElementById("cardViewModal")?.classList.add("hidden");
}

function updateHomeStars() {
  const el = document.getElementById("homeStarStat");
  if (el) el.textContent = state.stars || 0;
  const cc = document.getElementById("homeCharCount");
  if (cc && typeof CHARACTERS !== "undefined") cc.textContent = CHARACTERS.length;
}

function renderHomeBooks() {
  const grid = document.getElementById("homeBookGrid");
  if (!grid || typeof BOOKS === "undefined") return;
  grid.innerHTML = BOOKS.map(b => {
    const done = (state.completedBooks || []).includes(b.id);
    return `<button class="home-cover-card" onclick="openBook(${b.id})" title="${b.shortTitle || b.title}">
      <img src="images/covers/book${b.id}.jpg" alt="${b.shortTitle || b.title}" loading="lazy"
        onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
      <span class="home-cover-fallback" style="display:none">${b.emoji || "📘"}</span>
      <span class="home-cover-title">${b.shortTitle || b.title}</span>
      ${done ? '<span class="home-cover-done">✓</span>' : ""}
    </button>`;
  }).join("");
}


function renderMaps() {
  const selector = document.getElementById("mapBookSelector");
  // World areas overview
  selector.innerHTML = WORLD_AREAS.map(a => {
    const unlocked = isAreaUnlocked(a.book);
    const visited = (state.visitedMaps||[]).includes(a.book);
    return `
      <button class="map-book-btn ${a.book === currentMapBook ? "active" : ""} ${unlocked ? "" : "area-locked"}"
        onclick="selectMapBook(${a.book})">
        <span style="font-size:2rem;">${unlocked ? a.emoji : "🔒"}</span>
        <span>${a.name}${visited ? " ✓" : ""}${(typeof getMapSticker==="function" && getMapSticker(a.book)) ? " " + getMapSticker(a.book) : ""}</span>
        <small>${unlocked ? (visited ? "Visited" : "Unlocked") : a.lockedDesc}</small>
      </button>`;
  }).join("");
  drawStoryMap(currentMapBook);
}

function selectMapBook(id) {
  if (typeof markMapVisited === "function") markMapVisited(id);
  currentMapBook = id;
  renderMaps();
  document.getElementById("mapLocationDetail").innerHTML = "";
}

function drawStoryMap(bookId) {
  if (typeof markMapVisited === "function") markMapVisited(bookId);
  const map = STORY_MAPS[bookId];
  const container = document.getElementById("storyMapContainer");
  const unlocked = isAreaUnlocked(bookId);

  if (!map) {
    container.innerHTML = '<div class="map-placeholder">Map coming soon</div>';
    return;
  }

  if (!unlocked && !map.image) {
    container.innerHTML = `
      <div class="story-map map-theme-night">
        <h3 class="map-title">🔒 Area Locked</h3>
        <div class="map-canvas" style="display:flex;align-items:center;justify-content:center;">
          <div style="text-align:center;color:white;padding:2rem;">
            <div style="font-size:3rem;">🗺️</div>
            <p style="font-size:1.2rem;margin-top:1rem;">Complete <strong>Book ${bookId}</strong> to reveal this world and unlock its characters for purchase.</p>
          </div>
        </div>
      </div>`;
    return;
  }
  const lockNote = !unlocked
    ? `<p class="map-lock-note">🔒 Finish Book ${bookId} to unlock this area's characters for purchase. You can still explore the map!</p>`
    : "";

  const themeClass = `map-theme-${map.theme}`;
  const areaChars = CHARACTERS.filter(c => c.book === bookId);
  let pins = map.locations.map(loc => `
    <button class="map-pin" style="left:${loc.x}%; top:${loc.y}%;" onclick="showMapLocation('${bookId}','${loc.id}')" title="${loc.name}">
      <span class="pin-emoji">${loc.emoji}</span>
      <span class="pin-label">${loc.name}</span>
    </button>
  `).join("");

  const charList = areaChars.map(c => {
    const has = state.unlockedCharacters.includes(c.id);
    return `<span class="map-char-chip ${has ? "owned" : ""}">${c.emoji} ${c.name} · ⭐${c.cost}</span>`;
  }).join("");

  const mapArt = map.image
    ? `<div class="map-image-wrap"><img src="${map.image}" alt="${map.title}" class="map-full-image"><div class="map-pin-overlay">${pins}</div></div>`
    : `<div class="map-canvas">${pins}
        <svg class="map-path" viewBox="0 0 100 100" preserveAspectRatio="none">
          <polyline points="${map.locations.map(l => `${l.x},${l.y}`).join(" ")}"
            fill="none" stroke="rgba(255,255,255,0.5)" stroke-width="0.8" stroke-dasharray="2,2"/>
        </svg></div>`;

  container.innerHTML = `
    <div class="story-map ${themeClass}">
      <h3 class="map-title">${map.title}</h3>
      ${mapArt}
      ${lockNote}<p class="map-hint">Tap a story stop on the map · Characters from this area can be bought with ⭐</p>
      <div class="map-char-list">${charList}</div>
    </div>
  `;
}

function showMapLocation(bookId, locId) {
  const map = STORY_MAPS[bookId];
  const loc = map.locations.find(l => l.id === locId);
  if (!loc) return;
  document.getElementById("mapLocationDetail").innerHTML = `
    <div class="location-card">
      <div class="location-emoji">${loc.emoji}</div>
      <div>
        <h4>${loc.name}</h4>
        <p>${loc.desc}</p>
      </div>
    </div>
  `;
}


// Scenic/weather animations removed
document.addEventListener("DOMContentLoaded", () => {
  if (typeof ensureFeatureState === "function") ensureFeatureState();
  if (typeof checkBadges === "function") checkBadges();
  if (typeof renderHomeBooks === "function") renderHomeBooks();
  if (typeof updateHomeStars === "function") updateHomeStars();
  const st = document.getElementById("soundToggle");
  if (st) st.textContent = (localStorage.getItem("papiSound") !== "off") ? "🔊 Sound" : "🔇 Muted";
});

// ----- Init -----

// ===== Free starter card (claim once) =====
// First 10 claims on this browser get Papi; later claims get a random friend.
// Each device/browser may claim only ONE free card.

function updateFreeCardBanner() {
  const banner = document.getElementById("freeCardBanner");
  if (!banner) return;
  if (state.freeCardClaimed) {
    banner.classList.add("hidden");
  } else {
    banner.classList.remove("hidden");
  }
}

function pickFreeCardId() {
  // Count how many free cards this browser has ever issued
  let total = parseInt(localStorage.getItem("lplFreeClaimsTotal") || "0", 10);
  if (isNaN(total) || total < 0) total = 0;

  let freeId;
  if (total < 10) {
    // First 10 claims → Papi
    freeId = "papi";
  } else {
    // After that → random non-villain friend (not already owned)
    const friends = CHARACTERS.filter(c =>
      !c.isVillain &&
      !(state.unlockedCards || []).includes(c.id) &&
      !(state.unlockedCharacters || []).includes(c.id)
    );
    if (friends.length === 0) {
      // fallback: any non-villain
      const any = CHARACTERS.filter(c => !c.isVillain);
      freeId = any.length ? any[Math.floor(Math.random() * any.length)].id : "papi";
    } else {
      freeId = friends[Math.floor(Math.random() * friends.length)].id;
    }
  }
  localStorage.setItem("lplFreeClaimsTotal", String(total + 1));
  return freeId;
}

function claimFreeCard() {
  if (state.freeCardClaimed) {
    if (typeof showToast === "function") showToast("You already claimed your free card!");
    return;
  }

  const freeId = pickFreeCardId();
  const c = CHARACTERS.find(ch => ch.id === freeId);
  if (!c) {
    if (typeof showToast === "function") showToast("Could not pick a free card");
    return;
  }

  // Unlock character + card
  if (!state.unlockedCharacters.includes(freeId)) state.unlockedCharacters.push(freeId);
  if (!state.unlockedCards.includes(freeId)) state.unlockedCards.push(freeId);

  state.freeCardClaimed = true;
  state.freeCardId = freeId;
  saveState();
  updateFreeCardBanner();

  // Refresh UI
  if (typeof renderCharacters === "function") renderCharacters();
  if (typeof renderCardCollection === "function") renderCardCollection();
  if (typeof renderMyAlbum === "function") renderMyAlbum();
  if (typeof updateStarsDisplay === "function") updateStarsDisplay();

  // Open the full card so the child sees what they got
  if (typeof viewCard === "function") viewCard(freeId);
  if (typeof showToast === "function") showToast("🎁 You got " + c.name + " free!");
  if (typeof sfx === "function") sfx("win");
}


loadState();
renderBooks();
renderHomeWidgets();
showSection("home");

function showCardsTab(tab) {
  const shop = document.getElementById("cardsShopPanel");
  const album = document.getElementById("cardsAlbumPanel");
  const tShop = document.getElementById("tabShop");
  const tAlbum = document.getElementById("tabAlbum");
  if (tab === "album") {
    shop?.classList.add("hidden");
    album?.classList.remove("hidden");
    tAlbum?.classList.add("active");
    tShop?.classList.remove("active");
    if (typeof renderMyAlbum === "function") renderMyAlbum();
  if (typeof renderSetProgressRings === "function") renderSetProgressRings();
  } else {
    album?.classList.add("hidden");
    shop?.classList.remove("hidden");
    tShop?.classList.add("active");
    tAlbum?.classList.remove("active");
    renderCardCollection();
  }
}

function renderHomeQuizzes() {
  const el = document.getElementById("homeQuizRow");
  if (!el || typeof BOOKS === "undefined") return;
  const done = state.completedBooks || [];
  const passed = state.quizzesPassed || [];
  const pending = done.filter(id => !passed.includes(id));
  if (!pending.length) { el.innerHTML = ""; return; }
  el.innerHTML = `<p class="section-sub">Quizzes ready:</p><div class="home-quiz-chips">` +
    pending.map(id => {
      const b = BOOKS.find(x => x.id === id);
      return `<button class="btn btn-small" onclick="openQuiz(${id})">🧠 ${b ? (b.shortTitle||b.title) : "Book "+id}</button>`;
    }).join("") + `</div>`;
}


function closeNavMore() {
  const m = document.getElementById("navMoreMenu");
  if (m) {
    m.classList.add("hidden");
    m.style.display = "none";
  }
  document.querySelector(".navbar")?.classList.remove("more-open");
  document.getElementById("navMoreBtn")?.setAttribute("aria-expanded", "false");
}

function toggleNavMore(ev) {
  if (ev) {
    ev.preventDefault();
    ev.stopPropagation();
  }
  const m = document.getElementById("navMoreMenu");
  if (!m) return;
  const isHidden = m.classList.contains("hidden") || m.style.display === "none";
  if (isHidden) {
    m.classList.remove("hidden");
    m.style.display = "flex";
    document.querySelector(".navbar")?.classList.add("more-open");
    document.getElementById("navMoreBtn")?.setAttribute("aria-expanded", "true");
  } else {
    closeNavMore();
  }
}

document.addEventListener("click", (e) => {
  const wrap = document.getElementById("navMoreWrap") || document.querySelector(".nav-more-wrap");
  const m = document.getElementById("navMoreMenu");
  if (!m || !wrap) return;
  if (!wrap.contains(e.target)) closeNavMore();
});

// Close more menu when navigating
if (!window._navMoreWrapped) {
  window._navMoreWrapped = true;
  const _showSectionNav = showSection;
  window.showSection = function(sectionId) {
    document.getElementById("navMoreMenu")?.classList.add("hidden");
    return _showSectionNav(sectionId);
  };
}

function updateHeroPrimary() {
  const btn = document.getElementById("heroPrimaryBtn");
  const hint = document.getElementById("homeNextHint");
  if (!btn || typeof BOOKS === "undefined") return;
  let best = null;
  BOOKS.forEach(b => {
    const prog = state.bookProgress && state.bookProgress[b.id];
    const done = (state.completedBooks || []).includes(b.id);
    if (!done && prog != null && prog >= 0) best = b;
  });
  if (!best && state.currentBookId) {
    const b = BOOKS.find(x => x.id === state.currentBookId);
    if (b && !(state.completedBooks || []).includes(b.id)) best = b;
  }
  if (best) {
    btn.textContent = "📖 Continue: " + (best.shortTitle || best.title);
    btn.onclick = () => openBook(best.id);
    if (hint) hint.style.display = "none";
  } else {
    btn.textContent = "📖 Explore Books";
    btn.onclick = () => showSection("books");
    if (hint) hint.style.display = "";
  }
}


function renderHomeFriendRow() {
  const row = document.getElementById("homeFriendRow");
  if (!row || typeof CHARACTERS === "undefined") return;
  // Featured main friends first
  const prefer = ["papi","rosie","sammy","oliver","toby","felix","benny"];
  const list = [];
  prefer.forEach(id => {
    const c = CHARACTERS.find(x => x.id === id);
    if (c) list.push(c);
  });
  CHARACTERS.forEach(c => {
    if (!list.find(x => x.id === c.id) && !c.isVillain && list.length < 10) list.push(c);
  });
  row.innerHTML = list.slice(0, 8).map(c => {
    const unlocked = (state.unlockedCharacters || []).includes(c.id);
    const src = (c.id === "papi" && true)
      ? "images/characters/papi-avatar.jpg"
      : (c.card || "");
    const img = src
      ? `<img src="${src}" alt="${c.name}" loading="lazy" class="lpl-friend-img">`
      : `<span class="lpl-friend-emoji">${c.emoji||"🐾"}</span>`;
    return `<button class="lpl-friend-chip ${unlocked ? "unlocked" : "locked"}" onclick="showSection('characters'); setTimeout(()=>showCharacter('${c.id}'),80)">
      <div class="lpl-friend-avatar">${img}${unlocked ? "" : "<span class='lpl-lock'>🔒</span>"}</div>
      <span class="lpl-friend-name">${c.name}</span>
    </button>`;
  }).join("");
}


function renderHomeColourFan() {
  const el = document.getElementById("homeColourFan");
  if (!el || typeof COLOURING_PAGES === "undefined") return;
  const pages = COLOURING_PAGES.filter(p => p.image).slice(0, 4);
  el.innerHTML = pages.map((p, i) =>
    `<img src="${p.image}" alt="${p.title}" class="fan-card fan-c-${i}" loading="lazy" onclick="showSection('colouring')">`
  ).join("");
}

function renderHomePlayFan() {
  const el = document.getElementById("homePlayFan");
  if (!el) return;
  // promo tiles with real art samples
  const cards = (typeof CHARACTERS !== "undefined")
    ? CHARACTERS.filter(c => c.card).slice(0, 3)
    : [];
  let html = cards.map((c, i) =>
    `<img src="${c.card}" alt="${c.name}" class="fan-card fan-p-${i}" loading="lazy" onclick="showSection('cards')">`
  ).join("");
  // maps emoji cards
  html += `
    <div class="fan-promo fan-p-map" onclick="showSection('maps')">🗺️<span>Maps</span></div>
    <div class="fan-promo fan-p-stick" onclick="showSection('stickers')">🌟<span>Stickers</span></div>`;
  el.innerHTML = html;
}
