# Little Paws Library (Updated – Page Reader + Quizzes + Cards)

Interactive children's website for **The Adventures of Papi** series by Reshen Maharaj.

## What's new in this version

### Reading experience (major change)
- Books are now read **page by page** (not chapter summaries)
- Large page images with Previous Page / Next Page buttons
- Progress bar shows real page progress
- Character unlocks still happen as you reach key pages
- Stars awarded while reading and big bonus on finishing a book

### Quizzes
- Every book quiz now has **at least 5 questions**

### Free starter card
- One free character card per device — must be **claimed** (not automatic)
- First 10 claims on that browser get **Papi**
- After that, a random friend character is given
- Claim button appears on the home screen until used

### Cards
- Click any collected card → opens a full card view (big image + traits + description)
- **Papi is a free starter card** (always unlocked)
- Traits shown on cards (Brave, Kind, etc.)

### Colouring
- Children can colour directly on the website (brush, fill, eraser)
- **Download** button saves the coloured page as a PNG to the device

### Earlier fixes still included
- All 45 characters properly defined (including Bella, Ollie, Manny, Tyson, Paulie, TJ)
- Book 6 page 14 restored
- Colouring progress tracking fixed
- Locked character icon fixed

## How to open / publish
1. Unzip the folder
2. Drag the whole folder onto https://app.netlify.com/drop
3. Or open index.html locally

## Parent tip
Parent PIN is under More → Parent. Kids: Read pages → earn ⭐ → unlock friends, cards & colouring.
